"""Lifecycle of this kit only. No registry edits, privileged installs or global kill."""
from pathlib import Path
import argparse,base64,hashlib,json,os,platform,shutil,socket,subprocess,sys,tarfile,time,urllib.request,zipfile,sqlite3
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from assets import download
OS={'Windows':'windows','Darwin':'macos','Linux':'linux'}[platform.system()]
ARCH='arm64' if platform.machine().lower() in ['arm64','aarch64'] else 'x64'
STATE=ROOT/'data/state';LOGS=ROOT/'data/logs'
DEFAULT={'ollama_url':'http://127.0.0.1:11439','mcp_port':11440,'chat_model':'qwen3.5:9b','embedding_model':'qwen3-embedding:0.6b','context':32768,'max_output_tokens':1600,'temperature':0.2,'chat_thinking':False,'offline':False,'cherry_profile':'runtime/cherry/data' if OS=='windows' else 'data/cherry-profile'}
def config():
    p=ROOT/'data/config.json'
    return {**DEFAULT,**(json.loads(p.read_text(encoding='utf-8')) if p.exists() else {})}
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def api(path,body=None,timeout=5):
    from mgtu_mcp.knowledge import ollama
    return ollama(path,body,timeout)
def unpack(source,dest):
    dest.mkdir(parents=True,exist_ok=True)
    if source.suffix=='.zip':
        with zipfile.ZipFile(source) as z:
            for i in z.infolist():
                target=(dest/i.filename).resolve()
                if target!=dest.resolve() and dest.resolve() not in target.parents:raise RuntimeError('Unsafe ZIP member')
            z.extractall(dest)
    else:
        if source.name.endswith('.zst'):
            import zstandard
            with source.open('rb') as f,zstandard.ZstdDecompressor().stream_reader(f) as reader,tarfile.open(fileobj=reader,mode='r|') as t:t.extractall(dest,filter='data')
        else:
            with tarfile.open(source) as t:t.extractall(dest,filter='data')
def assets():return json.loads((ROOT/'assets.lock.json').read_text(encoding='utf-8'))['assets']
def asset(name):return next(a for a in assets() if a['name']==name)
def binaries():
    if OS=='windows':return ROOT/'runtime/ollama/ollama.exe',ROOT/'runtime/cherry/Cherry-Studio.exe'
    if OS=='linux':return ROOT/'runtime/ollama/bin/ollama',ROOT/'runtime/cherry/Cherry-Studio.AppImage'
    return ROOT/'runtime/ollama/ollama',ROOT/'runtime/cherry/Cherry Studio.app/Contents/MacOS/Cherry Studio'
def setup_runtimes():
    ollama,cherry=binaries();version=json.loads((ROOT/'assets.lock.json').read_text())
    if not ollama.exists():
        suffix='amd64' if ARCH=='x64' else 'arm64'
        name=f'ollama-windows-{suffix}.zip' if OS=='windows' else (f'ollama-linux-{suffix}.tar.zst' if OS=='linux' else 'ollama-darwin.tgz')
        unpack(download(asset(name)),ROOT/'runtime/ollama')
    if not cherry.exists():
        version=version['cherry_version'];directory=ROOT/'runtime/cherry';directory.mkdir(parents=True,exist_ok=True)
        if OS=='windows':shutil.copy2(download(asset(f'Cherry-Studio-{version}-win-{ARCH}-portable.exe')),cherry)
        elif OS=='linux':shutil.copy2(download(asset(f'Cherry-Studio-{version}-linux-{ARCH}.AppImage')),cherry)
        else:
            archive=download(asset(f'Cherry-Studio-{version}-mac-{ARCH}.zip'))
            subprocess.run(['/usr/bin/ditto','-x','-k',str(archive),str(directory)],check=True)
    if OS!='windows':ollama.chmod(ollama.stat().st_mode|0o111);cherry.chmod(cherry.stat().st_mode|0o111)
def child_env(component):
    env=os.environ.copy();cfg=config();home=ROOT/'data'/('ollama/home' if component=='ollama' else 'cherry-home');home.mkdir(parents=True,exist_ok=True)
    env.update(HOME=str(home),USERPROFILE=str(home),PYTHONUTF8='1',MGTU_ROOT=str(ROOT),MGTU_PROJECT='mgtu',PYTHONPATH=str(ROOT),PATH=str(Path(sys.executable).parent)+os.pathsep+env.get('PATH',''))
    for folder in ['Desktop','Documents','Downloads']:(home/folder).mkdir(parents=True,exist_ok=True)
    if OS=='windows':
        for key,rel in [('APPDATA','AppData/Roaming'),('LOCALAPPDATA','AppData/Local')]:
            p=home/rel;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
    if OS=='linux' and component=='cherry':
        # Official AppImage extract-and-run mode avoids a privileged FUSE installation.
        env['APPIMAGE_EXTRACT_AND_RUN']='1'
    if component=='ollama':env.update(OLLAMA_HOST=cfg['ollama_url'].split('://')[1],OLLAMA_MODELS=str(ROOT/'data/ollama/models'),OLLAMA_NO_CLOUD='1',OLLAMA_CONTEXT_LENGTH=str(cfg['context']),OLLAMA_NUM_PARALLEL='1',OLLAMA_MAX_LOADED_MODELS='2',OLLAMA_KEEP_ALIVE='-1')
    return env
def identity(process):
    import psutil
    p=psutil.Process(process.pid)
    return {'pid':p.pid,'created':p.create_time(),'executable':p.exe()}
def owned(name):
    import psutil
    p=STATE/(name+'.json')
    if not p.exists():return None
    value=json.loads(p.read_text())
    try:
        process=psutil.Process(value['pid'])
        if abs(process.create_time()-value['created'])<.01 and os.path.normcase(process.exe())==os.path.normcase(value['executable']):return process
    except psutil.Error:pass
    return None
def spawn(name,args,env):
    STATE.mkdir(parents=True,exist_ok=True);LOGS.mkdir(parents=True,exist_ok=True)
    with (LOGS/(name+'.log')).open('a',encoding='utf-8') as log:
        p=subprocess.Popen([str(a) for a in args],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),start_new_session=OS!='windows')
    write(STATE/(name+'.json'),identity(p));return p
def start_ollama():
    if owned('ollama'):
        api('/api/version');return
    port=int(config()['ollama_url'].rsplit(':',1)[1])
    with socket.socket() as probe:
        try:probe.bind(('127.0.0.1',port))
        except OSError:raise RuntimeError(f'Порт {port} занят чужим процессом. Измените ollama_url в data/config.json; чужой сервис не останавливается.')
    p=spawn('ollama',[binaries()[0],'serve'],child_env('ollama'))
    for _ in range(90):
        if p.poll() is not None:raise RuntimeError('Ollama завершилась. См. data/logs/ollama.log')
        try:api('/api/version');return
        except Exception:time.sleep(.5)
    raise RuntimeError('Не дождались запуска Ollama.')
def generate_imports():
    cfg=config();directory=ROOT/'imports';directory.mkdir(exist_ok=True)
    prompt=(ROOT/'config/system_prompt.ru.md').read_text(encoding='utf-8')
    write(directory/'assistant.json',[{'name':'Ассистент МГТУ','emoji':'🎓','group':['МГТУ'],'prompt':prompt,'description':'Локальная Qwen, документы и официальные ресурсы МГТУ','regularPhrases':[{'title':'Разбери файл','content':'Разбери прикреплённый файл: основные положения и таблицы, со ссылками на разделы.'},{'title':'Сравни документы','content':'Сравни прикреплённые документы и укажи источники различий.'},{'title':'Найди в базе','content':'Найди ответ в базе знаний МГТУ: '},{'title':'Проверь в интернете','content':'Проверь информацию в интернете, начиная с официальных ресурсов МГТУ: '}],'type':'agent'}])
    # Supported import schema; no absolute paths, secrets or unsupported configuration fields.
    mcp={'mcpServers':{'МГТУ — локальные документы и сайты':{'command':str(Path(sys.executable)),'args':['-m','mgtu_mcp'],'env':{'MGTU_ROOT':str(ROOT),'MGTU_PROJECT':'mgtu','PYTHONUTF8':'1','PYTHONPATH':str(ROOT)}}}}
    write(directory/'mcp-local.json',mcp)
    # Relocatable template depends on the launcher PATH/PYTHONPATH; generated local file is more reliable for first import.
    write(directory/'mcp-portable.json',{'mcpServers':{'МГТУ — локальные документы и сайты':{'command':'python','args':['-m','mgtu_mcp'],'env':{'PYTHONUTF8':'1','MGTU_PROJECT':'mgtu'}}}})
    write(directory/'mcp-http.json',{'mcpServers':{'МГТУ — локальные документы и сайты':{'type':'streamableHttp','baseUrl':f"http://127.0.0.1:{cfg['mcp_port']}/mcp"}}})
    (directory/'mcp-uri.txt').write_text('cherrystudio://mcp/install?servers='+base64.urlsafe_b64encode((directory/'mcp-http.json').read_bytes()).decode(),encoding='utf-8')
    provider={'id':'ollama','baseUrl':f"http://127.0.0.1:{cfg['mcp_port']}",'apiKey':'ollama','type':'ollama'}
    write(directory/'provider.json',provider)
    (directory/'provider-uri.txt').write_text('cherrystudio://providers/api-keys?v=1&data='+base64.urlsafe_b64encode(json.dumps(provider).encode()).decode(),encoding='utf-8')
def setup():
    (ROOT/'data').mkdir(exist_ok=True)
    if not (ROOT/'data/config.json').exists():write(ROOT/'data/config.json',DEFAULT)
    setup_runtimes();start_ollama();cfg=config()
    present={m['name'] for m in api('/api/tags')['models']}
    for model in [cfg['embedding_model'],cfg['chat_model']]:
        if model not in present:
            if cfg['offline']:raise RuntimeError('В автономном режиме отсутствует модель '+model)
            subprocess.run([str(binaries()[0]),'pull',model],env=child_env('ollama'),check=True)
    lock=ROOT/'models.lock.json'
    if lock.exists():
        expected={m['name']:m['digest'] for m in json.loads(lock.read_text(encoding='utf-8'))['models']}
        for m in api('/api/tags')['models']:
            if m['name'] in expected and m['digest']!=expected[m['name']]:
                raise RuntimeError('Ревизия '+m['name']+' отличается от проверенной models.lock.json. Проверьте обновление модели перед использованием и перестройте индекс.')
    generate_imports()
    print('Компоненты и модели готовы. Запустите start, затем выполните короткий импорт из docs/START_RU.md.')
def configure_boot():
    # Pinned official BootConfig format, within this kit's isolated HOME only.
    if OS=='windows':return
    from datetime import datetime
    path=ROOT/'data/cherry-home/.cherrystudio/boot-config.json';profile=ROOT/config()['cherry_profile'];profile.mkdir(parents=True,exist_ok=True)
    value=json.loads(path.read_text()) if path.exists() else {}
    exe=binaries()[1]
    key=str(exe.parent/'cherry-studio.appimage') if OS=='linux' else str(exe)
    if value.get('app.user_data_path',{}).get(key)==str(profile):return
    if path.exists():shutil.copy2(path,path.with_name('boot-config.backup-'+str(time.time_ns())+'.json'))
    value.setdefault('app.user_data_path',{})[key]=str(profile);write(path,value)
def start(uri=None):
    start_ollama();start_tools();generate_imports();configure_boot()
    present={m['name'] for m in api('/api/tags')['models']}
    for model in [config()['chat_model'],config()['embedding_model']]:
        if model not in present:raise RuntimeError('Отсутствует '+model+'. Сначала выполните setup.')
    if owned('cherry') and not uri:print('Cherry Studio уже запущена этим комплектом.');return
    if uri:backup_before_import()
    args=[binaries()[1],'--force-renderer-accessibility']
    if uri:args.append((ROOT/'imports'/('mcp-uri.txt' if uri=='tools' else 'provider-uri.txt')).read_text(encoding='utf-8'))
    if uri and owned('cherry'):
        subprocess.Popen([str(a) for a in args],cwd=ROOT,env=child_env('cherry'),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    else:spawn('cherry',args,child_env('cherry'))
    print('Открыта Cherry Studio. Данные сохраняются в каталоге комплекта.')
def backup_before_import():
    # Consistent online SQLite snapshot, including attachments; never modify Cherry databases.
    profile=ROOT/config()['cherry_profile'];database=profile/'Data/cherrystudio.sqlite'
    if not database.exists():return
    target=ROOT/'backups'/('before-import-'+str(time.time_ns()));target.mkdir(parents=True)
    shutil.copytree(profile,target/'profile',ignore=shutil.ignore_patterns('*.sqlite','*.sqlite-wal','*.sqlite-shm','Cache','GPUCache','Code Cache','Runtime','Crashpad'))
    dest=target/'profile/Data/cherrystudio.sqlite';dest.parent.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(database.as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(dest) as dst:src.backup(dst)
    print('Копия настроек перед импортом: '+str(target))
def stop():
    import psutil
    for name in ['cherry','tools','ollama']:
        p=owned(name)
        if not p:continue
        # Match identity immediately before signal; only descendants of the owned process.
        children=p.children(recursive=True)
        for child in reversed(children):
            try:child.terminate()
            except psutil.Error:pass
        try:p.terminate()
        except psutil.Error:pass
        _,alive=psutil.wait_procs(children+[p],timeout=8)
        for process in alive:
            try:process.kill()
            except psutil.Error:pass
        print('Остановлен '+name)
def start_tools():
    if owned('tools'):return
    port=int(config()['mcp_port'])
    with socket.socket() as probe:
        try:probe.bind(('127.0.0.1',port))
        except OSError:raise RuntimeError(f'Порт инструментов {port} занят чужим процессом. См. mcp_port в data/config.json.')
    p=spawn('tools',[sys.executable,'-m','mgtu_mcp.http_server'],child_env('tools'))
    for _ in range(40):
        try:
            request=urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with request.open(f'http://127.0.0.1:{port}/health',timeout=2) as r:
                if json.load(r)['service']=='mgtu-local-tools':return
        except Exception:time.sleep(.2)
        if p.poll() is not None:raise RuntimeError('Сервис инструментов завершился. См. data/logs/tools.log')
    raise RuntimeError('Не дождались инструментов.')
def doctor():
    import psutil
    result={'os':OS,'arch':ARCH,'python':sys.version,'ram_gib':round(psutil.virtual_memory().total/2**30,2),'disk_free_gib':round(shutil.disk_usage(ROOT).free/2**30,2),'runtimes':{str(p.relative_to(ROOT)):p.exists() for p in binaries()},'owned_ollama':bool(owned('ollama')),'owned_cherry':bool(owned('cherry'))}
    try:result.update(ollama=api('/api/version'),models=api('/api/tags')['models'],loaded=api('/api/ps')['models'])
    except Exception as e:result['error']=str(e)
    try:
        op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with op.open(f"http://127.0.0.1:{config()['mcp_port']}/health",timeout=3) as r:result['tools']=json.load(r)
    except Exception:result['tools_error']='Сервис инструментов недоступен. Выполните start; проверьте data/logs/tools.log.'
    write(ROOT/'reports/diagnostics.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
def backup():
    if owned('cherry'):raise RuntimeError('Сначала закройте Cherry Studio и выполните stop: копия открытой SQLite не считается надёжной.')
    target=ROOT/'backups'/time.strftime('%Y%m%d-%H%M%S');target.mkdir(parents=True,exist_ok=True)
    for rel in ['data/config.json','data/projects','runtime/cherry/data','data/cherry-profile','data/cherry-home/.cherrystudio']:
        p=ROOT/rel
        if p.is_file():target.joinpath(rel).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target/rel)
        elif p.is_dir():shutil.copytree(p,target/rel,ignore=shutil.ignore_patterns('Cache','GPUCache','Crashpad','Code Cache','attachment-cache'))
    print('Резервная копия: '+str(target)+'\nНе распространяйте её: она содержит ваши чаты и настройки.')
def main():
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['setup','start','stop','doctor','backup','import-provider','import-tools','index','offline','online']);a=parser.parse_args().action
    if a=='setup':setup()
    elif a=='start':start()
    elif a=='import-provider':start(uri=True)
    elif a=='import-tools':start(uri='tools')
    elif a=='stop':stop()
    elif a=='doctor':doctor()
    elif a=='backup':backup()
    elif a=='index':
        from mgtu_mcp.knowledge import synchronize
        print(json.dumps(synchronize(),ensure_ascii=False,indent=2))
    else:
        cfg=config();cfg['offline']=a=='offline';write(ROOT/'data/config.json',cfg);print('Режим изменён; уже запущенные MCP читают настройку при вызове.')
if __name__=='__main__':
    try:main()
    except Exception as e:print('Ошибка: '+str(e),file=sys.stderr);sys.exit(1)
