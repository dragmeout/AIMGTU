#!/bin/sh
set -eu
KIT_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ACTION=${1:-start}
case "$ACTION" in setup|start|stop|doctor|backup|index|import-provider|import-tools|offline|online) ;; *) echo 'Unknown action' >&2; exit 2;; esac
OS=$(uname -s); ARCH=$(uname -m)
case "$OS:$ARCH" in
Linux:x86_64) UV_NAME=uv-x86_64-unknown-linux-gnu.tar.gz; UV_SHA=c5221ff41b7892bfc223543883600125f6a47fe845093e0f5bdff4f359196d83;;
Linux:aarch64|Linux:arm64) UV_NAME=uv-aarch64-unknown-linux-gnu.tar.gz; UV_SHA=71279f8d3c67241e807b9d8db872d1bf541579fb9f08b7d1eb1682196d1e57dc;;
Darwin:x86_64) UV_NAME=uv-x86_64-apple-darwin.tar.gz; UV_SHA=20c47e4c1f630b8abaff8c291fa9b9aa300fef92c4fbff95adf198b55287cda7;;
Darwin:arm64) UV_NAME=uv-aarch64-apple-darwin.tar.gz; UV_SHA=81b811b57e4624df7ed3aac148e0359100d9962f3d9dce00aec533dc2e086731;;
*) echo 'Supported: macOS/Linux x64/arm64' >&2;exit 1;; esac
export UV_PYTHON_INSTALL_DIR="$KIT_ROOT/runtime/python-managed"
export UV_CACHE_DIR="$KIT_ROOT/.cache/uv"
export PYTHONUTF8=1
if [ "$ACTION" = setup ]; then
  mkdir -p "$KIT_ROOT/runtime/uv" "$KIT_ROOT/.cache/downloads"
  if [ ! -x "$KIT_ROOT/runtime/uv/uv" ]; then
    command -v curl >/dev/null || { echo 'curl is required';exit 1; }
    ARCHIVE="$KIT_ROOT/.cache/downloads/$UV_NAME"
    curl -fL --retry 3 --connect-timeout 20 -o "$ARCHIVE" "https://github.com/astral-sh/uv/releases/download/0.13.7/$UV_NAME"
    if command -v sha256sum >/dev/null;then ACTUAL=$(sha256sum "$ARCHIVE" | cut -d ' ' -f 1);else ACTUAL=$(shasum -a 256 "$ARCHIVE" | cut -d ' ' -f 1);fi
    [ "$ACTUAL" = "$UV_SHA" ] || { echo 'uv checksum mismatch';exit 1; }
    tar -xzf "$ARCHIVE" -C "$KIT_ROOT/runtime/uv" --strip-components=1
  fi
  "$KIT_ROOT/runtime/uv/uv" python install 3.13.17
fi
PYTHON=$(find "$UV_PYTHON_INSTALL_DIR" -type f -path '*/bin/python3.13' 2>/dev/null | head -n 1 || true)
[ -n "$PYTHON" ] || { echo 'Run: sh setup.sh';exit 1; }
if [ "$ACTION" = setup ];then
  "$KIT_ROOT/runtime/uv/uv" pip install --python "$PYTHON" -r "$KIT_ROOT/requirements.txt"
fi
exec "$PYTHON" "$KIT_ROOT/manager.py" "$ACTION"
