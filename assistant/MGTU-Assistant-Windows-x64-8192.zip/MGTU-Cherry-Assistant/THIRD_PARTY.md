# Сторонние компоненты

Бинарные файлы не изменены. Источники, версии и SHA256 указаны в lock-файлах. Лицензии находятся в `licenses/`, дополнительные лицензии Python-пакетов — в их `.dist-info` внутри Windows runtime.

| Компонент | Источник / лицензия |
|---|---|
| Cherry Studio 2.1.10 | [официальный исходник](https://github.com/CherryHQ/cherry-studio/tree/c60cd41a66d50920d75950fe3ed614c23bdeacca), AGPL-3.0; точный архив исходников включён в Windows Offline |
| Ollama 0.40.15 | [исходник](https://github.com/ollama/ollama/tree/v0.40.15), MIT |
| Python 3.13.17 | [python.org](https://www.python.org/downloads/), PSF и сопровождающие уведомления |
| uv 0.13.7 | [Astral](https://github.com/astral-sh/uv/tree/0.13.7), MIT/Apache-2.0; скачивается Unix bootstrap |
| Qwen3.5 9B | [карточка](https://ollama.com/library/qwen3.5:9b); текст лицензии из Ollama api/show сохранён |
| Qwen3 Embedding 0.6B | [карточка](https://ollama.com/library/qwen3-embedding:0.6b); текст лицензии из api/show сохранён |
| pypdf | BSD-3-Clause, [исходник](https://github.com/py-pdf/pypdf) |
| Beautiful Soup | MIT, [проект](https://www.crummy.com/software/BeautifulSoup/) |
| soupsieve | MIT, [исходник](https://github.com/facelessuser/soupsieve) |
| typing_extensions | PSF-2.0, [исходник](https://github.com/python/typing_extensions) |
| psutil | BSD-3-Clause, [исходник](https://github.com/giampaolo/psutil) |
| zstandard | BSD, [исходник](https://github.com/indygreg/python-zstandard); только Linux |

Для сборки Cherry используйте README и developer-документацию из включённого архива точного исходника; сохранены package.json и lock-файлы зависимостей. Этот комплект распространяет официальный готовый бинарный файл, свою сборку Cherry не производит.

Скрипты `manager.py`, `bootstrap.*`, `tools/update_sources.py` и код `mgtu_mcp` данного комплекта доступны по MIT (`LICENSE`). Университетские документы имеют собственные права и не покрываются лицензией кода. Сохраняйте атрибуцию из реестра источников.
