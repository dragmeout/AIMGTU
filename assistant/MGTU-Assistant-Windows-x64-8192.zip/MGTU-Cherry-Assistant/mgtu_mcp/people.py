"""Extract names literally supplied by a user; no lookup or invented identity."""
from __future__ import annotations
import re,unicodedata

WORD=re.compile(r'[А-ЯЁа-яё]+(?:-[А-ЯЁа-яё]+)*')
PATRONYMIC=re.compile(r'(?:ович|евич|ич|овна|евна|ична|инична)$',re.I)
SURNAME=re.compile(r'(?:ов|ев|ин|ын|ова|ева|ина|ына|ову|еву|ину|овой|евой|иной|ский|ская|ского|ской|цкий|цкая|ко|енко|ян|дзе|швили)$',re.I)
NOT_NAME=set('кто что какой какая какие какого какую как где когда почему можно нужно этой этого его ее неё него она он они их мне нам вам вы мы тут там такой такая это профессор доцент преподаватель сотрудник ректор декан проректор директор заведующий кафедра кафедры кафедре кафедру отдел отдела отделе отделу институт института институте управление управления библиотека библиотеки университет университета мгту носова практика практики стипендия стипендии расписание группы группа образовательный портал пароль покажи расскажи найди пожалуйста работа работает телефон контакты адрес правила положения положение документ документа педагогического образования вычислительной техники бизнес информатики информационных технологий экономики'.split())
NOT_NAME.discard('носова')
FIRST_NAMES=set('марина мария анна елена ольга наталья наталия татьяна ирина светлана юлия евгения ксения анастасия александра дарья валентина людмила галина надежда вера любовь нина иван петр пётр алексей александр андрей дмитрий сергей николай владимир виктор михаил максим павел денис роман игорь юрий геннадий григорий валерий василий евгений илья артем артём'.split())

def normalized(text):return unicodedata.normalize('NFKC',str(text)).casefold().replace('ё','е')
def display(text):return '-'.join(part[:1].upper()+part[1:].lower() for part in text.split('-'))
def _ok(word):return len(word)>=3 and normalized(word) not in NOT_NAME
def _person(name,surname,first=None,patronymic=None):
    name=' '.join(name.split());surname=display(surname)
    return {'name':name,'surname':surname,'query':surname,'first_name':display(first) if first else '',
            'patronymic':display(patronymic) if patronymic else ''}

def find_people(question):
    """Return unambiguous literal candidates in input order; preserve FIO order."""
    tokens=list(WORD.finditer(question));found=[];occupied=[];seen=set()
    for i in range(len(tokens)-2):
        group=tokens[i:i+3];a,b,c=[m[0] for m in group]
        if any(not _ok(w) for w in [a,b,c]):continue
        # Only spaces/hyphens belong inside a full name, never sentence breaks.
        if any(not re.fullmatch(r'\s+',question[group[j].end():group[j+1].start()]) for j in range(2)):continue
        if PATRONYMIC.search(c) and not PATRONYMIC.search(b):surname,first,patro=a,b,c
        elif PATRONYMIC.search(b) and not PATRONYMIC.search(c):surname,first,patro=c,a,b
        else:continue
        key=normalized('|'.join([surname,first,patro]))
        if key in seen:continue
        seen.add(key);occupied.append((group[0].start(),group[-1].end()))
        found.append(_person(' '.join(display(w) for w in [a,b,c]),surname,first,patro))
    # Initials are copied from the question, never inferred from a name dictionary.
    for m in re.finditer(r'([А-ЯЁа-яё][А-ЯЁа-яё-]{2,})\s+([А-ЯЁ])\.?\s*([А-ЯЁ])\.(?!\w)',question):
        if any(start<=m.start()<end for start,end in occupied) or not _ok(m[1]):continue
        if not SURNAME.search(m[1]) and not m[1][0].isupper():continue
        item=_person(f'{display(m[1])} {m[2]}. {m[3]}.',m[1]);item['query']=f'{item["surname"]} {m[2]}.{m[3]}.'
        if not any(normalized(x['surname'])==normalized(item['surname']) for x in found):found.append(item)
    if found:return found
    # Two-part names are accepted only when a given name is recognizable. The
    # display order remains exactly the user's order; no absent patronymic added.
    for i in range(len(tokens)-1):
        first,last=tokens[i:i+2];a,b=first[0],last[0]
        if not _ok(a) or not _ok(b) or not re.fullmatch(r'\s+',question[first.end():last.start()]):continue
        if normalized(a) in FIRST_NAMES and SURNAME.search(b) and not PATRONYMIC.search(b):surname=b
        elif normalized(b) in FIRST_NAMES and (SURNAME.search(a) or a[0].isupper()) and not PATRONYMIC.search(a):surname=a
        else:continue
        item=_person(f'{display(a)} {display(b)}',surname)
        if not any(normalized(x['surname'])==normalized(item['surname']) for x in found):found.append(item)
    if found:return found
    # A surname alone needs explicit person wording, or a name-shaped bare input.
    patterns=[r'\b(?:преподавател[яь]|сотрудник[а]?|профессор[а]?|доцент[а]?)\s+([А-ЯЁа-яё-]{3,})',
              r'\bкто\s+(?:такой|такая)\s+([А-ЯЁа-яё-]{3,})',
              r'\b(?:про|об|о)\s+([А-ЯЁа-яё-]{3,})']
    for pattern in patterns:
        for m in re.finditer(pattern,question,re.I):
            word=m[1]
            if not _ok(word):continue
            following=WORD.search(question,m.end())
            if following and PATRONYMIC.search(following[0]):continue
            if pattern==patterns[1] and not (SURNAME.search(word) or word[0].isupper()):continue
            if pattern==patterns[-1] and not (SURNAME.search(word) and (word[0].isupper() or re.search(r'(?:ова|ову|евой|овой|еву|ев|ов|ин|ян)$',word,re.I))):continue
            item=_person(display(word),word)
            if not any(normalized(x['surname'])==normalized(item['surname']) for x in found):found.append(item)
    if not found:
        m=re.fullmatch(r'\s*([А-ЯЁа-яё-]{3,})\s*[?!.]*',question)
        if m and _ok(m[1]) and SURNAME.search(m[1]):found=[_person(display(m[1]),m[1])]
    return found

def identify_person(question):
    """{'name','surname','query',...} only when exactly one person was named."""
    people=find_people(question)
    return people[0] if len(people)==1 else None

def person_initials(person):
    if person.get('first_name') and person.get('patronymic'):
        return normalized(person['first_name'][0]+person['patronymic'][0])
    match=re.search(r'\b([А-ЯЁ])\.\s*([А-ЯЁ])\.',person['name'],re.I)
    return normalized(match[1]+match[2]) if match else ''

def same_person(wanted,candidate):
    if normalized(wanted['surname'])!=normalized(candidate['surname']):return False
    for field in ['first_name','patronymic']:
        if wanted.get(field) and candidate.get(field) and normalized(wanted[field])!=normalized(candidate[field]):return False
    initials=person_initials(wanted)
    return not initials or person_initials(candidate)==initials

def matching_person(wanted,text):
    """A surname substring alone cannot establish identity, especially initials."""
    matches=[candidate for candidate in find_people(text) if same_person(wanted,candidate)]
    full=[candidate for candidate in matches if candidate.get('first_name') and candidate.get('patronymic')]
    return (full or matches or [None])[0]

def person_summary_facts(wanted,text):
    """Extract only labelled facts in this person's roster record."""
    person=matching_person(wanted,text)
    if not person or not person.get('first_name') or not person.get('patronymic'):return []
    mention=re.search(r'\s+'.join(map(re.escape,person['name'].split())),text,re.I)
    if not mention:return []
    tail=text[mention.end():]
    for other in find_people(tail):
        if not person_initials(other):continue
        if same_person(person,other):continue
        position=re.search(r'\s+'.join(map(re.escape,other['name'].split())),tail,re.I)
        if position:tail=tail[:position.start()]
    boundary=r'(?=Уч[её]н|Преподаваем|Общий стаж|Образован|Направлен|Контактн|Профессиональн|$)'
    facts=[person['name']]
    for label,pattern in [('Должность',r'(?:Занимаемая должность|Должность)'),('Учёная степень',r'Уч[её]ная степень')]:
        match=re.search(pattern+r'\s*:\s*(.+?)'+boundary,tail,re.I)
        if match:
            value=match[1].strip(' ;\t\n')
            if 1<len(value)<=200 and value!='-':facts.append(label+': '+value)
    return facts if any(line.startswith('Должность:') for line in facts) else []
