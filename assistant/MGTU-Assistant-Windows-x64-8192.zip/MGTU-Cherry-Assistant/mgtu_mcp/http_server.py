"""Stateless MCP Streamable HTTP, loopback only, JSON responses (no SSE required)."""
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
import json,sys,threading
from .__main__ import TOOLS,call_tool
from .knowledge import config
LIMIT=threading.BoundedSemaphore(4)
class Handler(BaseHTTPRequestHandler):
    server_version='MGTU-Local-Tools/1.0'
    def log_message(self,fmt,*args):print(fmt%args,file=sys.stderr,flush=True)
    def valid(self):
        host=self.headers.get('Host','');origin=self.headers.get('Origin','')
        if host not in [f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}']:return False
        return not origin or origin in ['file://',f'http://127.0.0.1:{self.server.server_port}']
    def reply(self,status,data=None):
        raw=b'' if data is None else json.dumps(data,ensure_ascii=False).encode('utf-8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers()
        if raw:self.wfile.write(raw)
    def do_GET(self):
        if not self.valid():return self.reply(403)
        if self.path=='/health':return self.reply(200,{'service':'mgtu-local-tools','version':'1.0.0'})
        if self.path in ['/api/version','/api/tags','/api/ps']:
            from .chat_bridge import relay
            try:return relay(self,self.path)
            except Exception:return self.reply(503,{'error':'Ollama недоступна. Запустите комплект и doctor.'})
        return self.reply(405)
    def do_DELETE(self):return self.reply(405)
    def do_POST(self):
        if not self.valid():return self.reply(403)
        if self.path not in ['/mcp','/api/chat','/api/show','/api/embed']:return self.reply(404)
        if 'application/json' not in self.headers.get('Content-Type',''):return self.reply(415)
        try:length=int(self.headers.get('Content-Length','0'))
        except ValueError:return self.reply(400)
        if not 0<length<=1_000_000:return self.reply(413,{'error':'Запрос превышает 1 MB. Для больших документов используйте индекс и поиск по фрагментам.'})
        if not LIMIT.acquire(blocking=False):return self.reply(429)
        ident=None
        try:
            self.connection.settimeout(30);raw=self.rfile.read(length)
            if self.path!='/mcp':
                from .chat_bridge import relay
                try:return relay(self,self.path,raw)
                except (ValueError,KeyError,TypeError) as e:return self.reply(400,{'error':str(e)})
                except Exception:return self.reply(503,{'error':'Локальная модель недоступна или превышено время ожидания. Выполните doctor.'})
            request=json.loads(raw);ident=request.get('id');method=request.get('method');params=request.get('params') or {}
            if ident is None:return self.reply(202)
            if method=='initialize':result={'protocolVersion':params.get('protocolVersion','2025-03-26'),'capabilities':{'tools':{'listChanged':False}},'serverInfo':{'name':'mgtu-local-tools','version':'1.0.0'}}
            elif method=='ping':result={}
            elif method=='tools/list':result={'tools':[{**t,'annotations':{'readOnlyHint':t['name']!='download_document','destructiveHint':False,'openWorldHint':t['name'] in ['web_search','fetch_page','download_document','search_schedule']}} for t in TOOLS]}
            elif method=='tools/call':
                try:
                    print('tool='+str(params.get('name','unknown'))[:80],file=sys.stderr,flush=True)
                    value=call_tool(params['name'],params.get('arguments',{}));result={'content':[{'type':'text','text':json.dumps(value,ensure_ascii=False)}],'isError':False}
                except Exception as e:result={'content':[{'type':'text','text':json.dumps({'error':str(e),'action':'Не утверждайте, что действие выполнено. Исправьте запрос или выполните диагностику.'},ensure_ascii=False)}],'isError':True}
            else:return self.reply(200,{'jsonrpc':'2.0','id':ident,'error':{'code':-32601,'message':'Method not found'}})
            return self.reply(200,{'jsonrpc':'2.0','id':ident,'result':result})
        except (ValueError,TypeError,KeyError) as e:return self.reply(400,{'jsonrpc':'2.0','id':ident,'error':{'code':-32602,'message':str(e)}})
        except (BrokenPipeError,ConnectionError):pass
        finally:LIMIT.release()
if __name__=='__main__':
    def warm():
        from .knowledge import ollama,embed
        try:
            cfg=config();ollama('/api/generate',{'model':cfg.get('chat_model','qwen3.5:9b'),'stream':False,'keep_alive':-1,'options':{'num_ctx':cfg.get('context',32768)}},timeout=240)
            embed(['МГТУ имени Носова']);print('Модели готовы и остаются загруженными до stop.',flush=True)
        except Exception as e:print('Подготовка моделей: '+str(e),file=sys.stderr,flush=True)
    threading.Thread(target=warm,daemon=True).start()
    server=ThreadingHTTPServer(('127.0.0.1',int(config().get('mcp_port',11440))),Handler);server.daemon_threads=True;server.serve_forever()
