"""Conversation-scoped lookups through the public university timetable."""
from __future__ import annotations
import json,re,unicodedata
from dataclasses import dataclass
from datetime import datetime,timedelta,timezone
from urllib.parse import urlencode,urljoin,urlsplit,unquote
from bs4 import BeautifulSoup
from .official_web import WebError

ROOT='https://timetable.magtu.ru/'
DAYS=['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье']
STEMS=['понедельник','вторник','сред','четверг','пятниц','суббот','воскресен']
GROUP=re.compile(r'(?<![\w-])([А-Яа-яЁёA-Za-z]{1,8}-\d{2}-\d{1,2}-\d{1,2})(?:_([1-9]\d?))?(?![\w-])')
ORDINALS={'перв':1,'втор':2,'трет':3,'четверт':4,'пят':5,'шест':6,'седьм':7,'восьм':8,'девят':9,'десят':10}

def norm(text):
    return unicodedata.normalize('NFKC',str(text)).translate(str.maketrans({'–':'-','—':'-','‑':'-','−':'-'})).casefold().replace('ё','е')

# Latin homoglyphs and common transliteration are normalized for comparison.
# No digit is guessed: compact codes are matched against names returned by the API.
LATIN=str.maketrans({'a':'а','b':'в','c':'с','d':'д','e':'е','f':'ф','g':'г','h':'н','i':'и','j':'й','k':'к','l':'л','m':'м','n':'н','o':'о','p':'р','r':'р','s':'с','t':'т','u':'у','v':'в','x':'х','y':'у','z':'з'})
@dataclass(frozen=True)
class GroupInput:
    prefix:str
    parts:tuple[str,...]=()
    compact:str=''
    subgroup:int|None=None
    aliases:tuple[str,...]=()
    def query(self):
        display=self.prefix.upper()
        if self.prefix[-1:] in 'бмсз':display=display[:-1]+display[-1:].lower()
        if self.parts:return display+'-'+'-'.join(self.parts)
        return display+('-'+self.compact[:2] if self.compact else '')

def normalize_prefix(text):
    text=norm(text)
    # The final Latin b is the study-level suffix, not a Russian В.
    suffix='б' if text.endswith('b') else ''
    return (text[:-1].translate(LATIN)+suffix) if suffix else text.translate(LATIN)

def group_input(prefix,parts=(),compact='',subgroup=None):
    primary=normalize_prefix(prefix)
    latin=norm(prefix)
    # Two common readings of Latin P/B/H are genuinely ambiguous. Search both
    # against the official names; never silently reinterpret a Cyrillic letter.
    translit=latin.translate(str.maketrans({'p':'п','h':'х','b':'б'}))
    alternative=normalize_prefix(translit)
    aliases=tuple(dict.fromkeys([primary,alternative]))
    return GroupInput(primary,parts,compact,subgroup,aliases)

def normalize_group(text):
    value=extract_group(text)
    if not value:return ''
    return value.prefix+''.join(value.parts or (value.compact,))

# Ordinary word + number is not a group: "после 18 часов", "через 20 минут".
GROUP_NON_PREFIX=set('я мы вы он она они мне моя наш нам вам нас вас им их без через после перед около свыше более менее плюс минус час часов лет дней дня день дата год года курс класс аудитория ауд кабинет пункт пункта статья корпус комната мест места балл баллов семестр семестра'.split())
def _group_prefix_in_context(match,text):
    prefix=normalize_prefix(match[1])
    # Retain explicitly written codes and other programmes named as a group.
    explicit=bool(re.match(r'[А-Яа-яЁёA-Za-z]+\s*[-/]',match[0]) or
                  re.search(r'групп[аыуе]\s*$',text[:match.start()],re.I))
    if explicit:return True
    if prefix in GROUP_NON_PREFIX:return False
    return len(prefix)>=2 and prefix[-1:] in 'бмсз'

def extract_group(text):
    text=unicodedata.normalize('NFKC',str(text)).translate(str.maketrans({'–':'-','—':'-','‑':'-','−':'-'}))
    # Separated codes accept spaces, slashes and dashes, including partial codes.
    for match in re.finditer(r'(?<![\w-])([А-Яа-яЁёA-Za-z]{1,8})\s*[-/]?\s*(\d{2})(?:(?:\s*[-/]\s*|\s+)(\d{1,2}))?(?:(?:\s*[-/]\s*|\s+)(\d{1,2}))?(?:_(\d{1,2}))?(?![\w-])',text):
        if _group_prefix_in_context(match,text):
            return group_input(match[1],tuple(x for x in match.group(2,3,4) if x),subgroup=int(match[5]) if match[5] else None)
    for match in re.finditer(r'(?<![\w-])([А-Яа-яЁёA-Za-z]{1,8})(\d{3,6})(?:_(\d{1,2}))?(?![\w-])',text):
        if _group_prefix_in_context(match,text):return group_input(match[1],compact=match[2],subgroup=int(match[3]) if match[3] else None)
    match=re.search(r'(?i:групп[аыуе]\s+)([А-Яа-яЁёA-Za-z]{2,8})(?![\w])',text)
    if not match:match=re.fullmatch(r'\s*([А-Яа-яЁёA-Za-z]{2,8})\s*[?.!]*',text)
    if match and normalize_prefix(match[1]) not in GROUP_NON_PREFIX and normalize_prefix(match[1])[-1:] in 'бмсз':return group_input(match[1])
    return None

def group_matches(candidate,asked):
    if not candidate or candidate.prefix not in (asked.aliases or (asked.prefix,)):return False
    if asked.compact:return ''.join(candidate.parts or (candidate.compact,)).startswith(asked.compact)
    return candidate.parts[:len(asked.parts)]==asked.parts

def exact_group(candidate,asked):
    if not candidate or candidate.prefix not in (asked.aliases or (asked.prefix,)):return False
    return ''.join(candidate.parts or (candidate.compact,))==asked.compact if asked.compact else candidate.parts==asked.parts

NAME_STOP={'а','в','во','на','по','завтра','сегодня','послезавтра','понедельник','вторник','среду','четверг','пятницу','субботу','группы','группа','моей','мой','как','что','когда','где','покажи','покажите','какое','какие','пары','занятия','расписание','нет'}
def teacher_query(question,bare=False):
    q=unicodedata.normalize('NFKC',question).strip(' ?!')
    patterns=[r'(?i:преподавател[яью]\s+|препод[ау]?\s+)(.+)',r'(?i:расписани[ея]\s+(?:у\s+)?)(.+)',r'(?i:(?:пары|занятия)\s+у\s+)(.+)']
    value=None
    for pattern in patterns:
        match=re.search(pattern,q)
        if match:value=match[1];break
    if value is None and bare:value=q
    if value is None:return None
    words=re.findall(r'[А-Яа-яЁёA-Za-z-]+\.?',value);names=[]
    for word in words[:3]:
        if norm(word).strip('.') in NAME_STOP and not word.endswith('.'):break
        if len(word.strip('.'))<2 and not word.endswith('.'):break
        names.append(word)
    if not names or len(names[0].strip('.'))<3:return None
    value=' '.join(names)
    # The timetable API publishes surname-first names/initials, while a user
    # may naturally supply "Марина Владимировна Махмутова". Reorder only the
    # literal supplied name; neither patronymic nor initials are invented.
    from .people import identify_person
    person=identify_person(value)
    if person and person['first_name']:
        return ' '.join(part for part in [person['surname'],person['first_name'],person['patronymic']] if part)
    if person and len(names)==2 and not any('.' in name for name in names):
        if norm(names[-1])==norm(person['surname']):return person['surname']+' '+names[0]
    return value

def filters(question):
    q=norm(question);day=None
    offset=2 if 'послезавтра' in q else (1 if 'завтра' in q else (0 if 'сегодня' in q else None))
    if offset is not None:day=DAYS[(datetime.now(timezone(timedelta(hours=5))).weekday()+offset)%7]
    else:
        matches=[(m.start(),DAYS[i]) for i,stem in enumerate(STEMS) for m in re.finditer(stem,q)]
        if matches:day=max(matches)[1]
    return {'day':day,'parity':'нечетная' if re.search(r'не\s*четн',q) else ('четная' if 'четн' in q else None)}

def lesson_mode(question):
    q=norm(question)
    if re.search(r'последн\w*\s+пар|(?:когда|во сколько).{0,20}(?:заканчива|конец)',q):return 'last'
    if re.search(r'перв\w*\s+пар|(?:когда|во сколько).{0,20}(?:начина|начало)',q):return 'first'
    for stem,number in ORDINALS.items():
        if re.search(r'\b'+stem+r'\w*\s+пар',q):return str(number)
    number=re.search(r'\b([1-9])\s*(?:[- ]?[яй])?\s+пар',q)
    return number[1] if number else None

def parse_schedule(body):
    soup=BeautifulSoup(body,'html.parser');weeks=[]
    for week in soup.select('.week'):
        label=week.select_one('.week-name');days=[]
        for day in week.select('.day'):
            name=day.select_one('.day-name');lessons=[]
            for lesson in day.select('.less'):
                values={}
                for key,selector in [('subject','.title'),('time','.time'),('room','.aud'),('teacher','.teacher'),('number','.couple-number')]:
                    node=lesson.select_one(selector);values[key]=node.get_text(' ',strip=True) if node else ''
                if values['subject']:lessons.append(values)
            days.append({'day':name.get_text(' ',strip=True) if name else '', 'lessons':lessons})
        weeks.append({'week':label.get_text(' ',strip=True) if label else '', 'days':days})
    if not weeks:raise WebError('Сайт изменил вид расписания. Не удалось прочитать таблицу.')
    return weeks

def format_schedule(name,weeks,question=''):
    chosen=filters(question);wanted=chosen['day'];parity=chosen['parity'];mode=lesson_mode(question)
    lines=[name];matched_week=False
    for week in weeks:
        if parity and norm(week['week'])!=parity:continue
        matched_week=True;lines.append('\n'+week['week']+' неделя');matched_day=False
        for day in week['days']:
            if wanted and norm(wanted) not in norm(day['day']):continue
            matched_day=True;lines.append(day['day']);lessons=day['lessons']
            if mode in ('first','last') and lessons:
                ordered=sorted(lessons,key=lambda item:item.get('time',''));selected_time=ordered[0 if mode=='first' else -1]['time']
                lessons=[item for item in lessons if item['time']==selected_time]
            elif mode:lessons=[item for item in lessons if item.get('number')==mode]
            if not lessons:lines.append('Эта пара в таблице не указана.' if mode else 'Занятия в таблице не указаны.')
            for lesson in lessons:lines.append(f"{lesson['time']} · {lesson['subject']} · ауд. {lesson['room'] or 'не указана'} · {lesson['teacher']}")
        if wanted and not matched_day:lines.append(wanted+': этот день отсутствует в опубликованной таблице.')
    if not matched_week:lines.append('Для указанной чётности недельная таблица не найдена.')
    if not parity:
        if len(weeks)>1:lines.append('\nПоказаны обе недели: сервис не указал, какая из них действует в выбранную дату.')
        else:lines.append('\nСоответствие недели календарной дате не указано; обе недели в этой таблице не опубликованы.')
    lines.append('Источник: расписание МГТУ. [S1]');return '\n'.join(lines)

class Timetable:
    def __init__(self,client):self.client=client;self._search_cache={};self.clear()
    def clear(self):self.pending=[];self.selected=None;self.candidates=[];self.active_filters={'day':None,'parity':None};self.mode=None;self.awaiting_target=False;self.suggestions=False
    def handles(self,question):
        q=norm(question)
        from .people import identify_person
        person=identify_person(question)
        if (self.pending or self.selected or self.awaiting_target) and person and norm(person['name'])==q.strip(' ?!.'):return True
        if re.search(r'телефон|контакт|почт|стипенди|общежит|парол|пропуст|посещаем|прогул',q):return False
        if 'расписан' in q or extract_group(question):return True
        if re.search(r'\bпар[аыуе]\b',q) and (filters(question)['day'] or re.search(r'какие|когда|во сколько|перв|последн|начина|заканчива|групп|преподавател',q)):return True
        if re.search(r'занятия\s+(?:сегодня|завтра)|(?:когда|во сколько).{0,20}занятия',q):return True
        if self.pending and (self._selection(question) is not None or self._subgroup(question) is not None):return True
        if self.pending and self.suggestions and re.fullmatch(r'(?:да|покажи|показать|подтверждаю|верно|эту|е[её]|нет|не эта)\s*[?!.]*',q):return True
        if self.selected and self._subgroup(question) is not None:return True
        if self.pending or self.selected:
            if filters(question)['day'] or filters(question)['parity']:
                return bool(re.fullmatch(r'(?:а\s+)?(?:что\s+)?(?:будет\s+)?(?:на\s+|во?\s+|по\s+)?(?:сегодня|завтра|послезавтра|понедельник\w*|вторник\w*|сред\w*|четверг\w*|пятниц\w*|суббот\w*|воскресен\w*|(?:не\s*)?четн\w*\s*(?:недел\w*)?)\s*[?!.]*',q))
            return bool(re.fullmatch(r'(?:а\s+)?(?:во сколько|когда|где|в какой аудитории|кто ведет|кто преподаватель|начало|конец|первая пара|последняя пара)\s*[?!.]*',q))
        return self.awaiting_target and bool(identify_person(question))
    def search(self,query):
        query=' '.join(query.split())
        if not 2<=len(query)<=100:raise ValueError('Введите от 2 до 100 символов: группу или фамилию.')
        _,body,_=self.client.fetch(ROOT+'api/v2/search?'+urlencode({'q':query}),schedule=True)
        try:data=json.loads(body)
        except (ValueError,UnicodeError) as error:raise WebError('Сервис расписания прислал нечитаемый ответ. Попробуйте позже.') from error
        if not isinstance(data,list):raise WebError('Неожиданный ответ поиска расписания.')
        results=[];seen=set()
        for item in data[:25]:
            if not isinstance(item,dict) or not isinstance(item.get('url'),str):continue
            url=urljoin(ROOT,item['url']);p=urlsplit(url)
            try:valid=p.scheme=='https' and p.hostname=='timetable.magtu.ru' and not p.username and not p.password and p.port in (None,443)
            except ValueError:valid=False
            if not valid or p.path.count('/')!=1 or not p.path.strip('/') or url in seen:continue
            seen.add(url);results.append({'name':str(item.get('name',''))[:160],'url':url,'type':item.get('type','')})
        return results
    def _lookup(self,query):
        key=norm(query)
        if key not in self._search_cache:
            if len(self._search_cache)>=32:self._search_cache.clear()
            self._search_cache[key]=self.search(query)
        return list(self._search_cache[key])
    @staticmethod
    def _match_teacher(items,query):
        words=re.findall(r'[а-яёa-z]+',norm(query));surname=words[0] if words else ''
        wanted=[w[0] for w in words[1:]]
        matched=[]
        for item in items:
            parts=re.findall(r'[а-яёa-z]+',norm(item['name']))
            if not parts or parts[0]!=surname:continue
            initials=[w[0] for w in parts[1:]]
            if not wanted or initials[:len(wanted)]==wanted:matched.append(item)
        return matched
    def read(self,item,question=''):
        url,body,_=self.client.fetch(item['url'],schedule=True);weeks=parse_schedule(body)
        return {'answer':format_schedule(item['name'],weeks,question),'sources':[{'id':'S1','title':item['name'],'url':url,'origin':'official_website','fetched_at':self.client.fetched_times.get(url),'pages':[]}], 'route':'search_schedule','schedule':weeks}
    @staticmethod
    def _subgroup(question):
        q=norm(question);digit=re.search(r'\b([1-9]\d?)\s*(?:[- ]?[яй])?\s*(?:подгр|п/г)',q)
        if digit:return int(digit[1])
        for stem,number in ORDINALS.items():
            if re.search(r'\b'+stem+r'\w*\s+подгр',q):return number
        group=extract_group(question);return group.subgroup if group else None
    @staticmethod
    def _item_subgroup(item):
        value=norm(item['name'])+' '+unquote(item['url']);match=re.search(r'\b([1-9]\d?)\s*подгр|_([1-9]\d?)\s*$',value)
        return int(match[1] or match[2]) if match else None
    def _selection(self,question):
        q=re.sub(r'^а\s+','',norm(question).strip(' ?!.'));subgroup=self._subgroup(question)
        if subgroup is not None:
            matches=[i for i,item in enumerate(self.pending) if self._item_subgroup(item)==subgroup]
            if len(matches)==1:return matches[0]
        for i,item in enumerate(self.pending):
            if q in (norm(item['name']),norm(unquote(urlsplit(item['url']).path)).strip('/')):return i
        number=re.fullmatch(r'(?:вариант\s*)?(\d{1,2})',q)
        if number:return int(number[1])-1
        for stem,value in ORDINALS.items():
            if re.fullmatch(stem+r'\w*(?:\s+вариант)?',q):return value-1
        return None
    def _update(self,question,reset=False):
        if reset:self.active_filters={'day':None,'parity':None};self.mode=None
        for key,value in filters(question).items():
            if value:self.active_filters[key]=value
        mode=lesson_mode(question)
        if mode:self.mode=mode
        elif re.search(r'все\s+пар|весь\s+день|полное\s+расписан',norm(question)):self.mode=None
    def _canonical(self):
        values=[self.active_filters['day'] or '',(self.active_filters['parity']+' неделя') if self.active_filters['parity'] else '']
        if self.mode:values.append({'first':'первая пара','last':'последняя пара'}.get(self.mode,self.mode+' пара'))
        return '. '.join(value for value in values if value)
    def _answer_selected(self):
        question=self._canonical();result=self.read(self.selected,question);result['resolved_question']='Расписание '+self.selected['name']+('. '+question if question else '');return result
    def _options(self):
        if self.suggestions and len(self.pending)==1:
            answer=f"Точного совпадения нет. На сайте нашёл {self.pending[0]['name']}. Показать её расписание? Ответьте «да» или уточните группу."
        else:answer=('Точного совпадения нет. Нашёл близкие варианты. ' if self.suggestions else '')+'Уточните вариант — ответьте его номером или назовите подгруппу:\n'+'\n'.join(f"{i}. {item['name']}" for i,item in enumerate(self.pending,1))
        return {'answer':answer,'sources':[],'route':'clarify','requires_confirmation':self.suggestions,'schedule_choices':[{'number':i,'name':item['name']} for i,item in enumerate(self.pending,1)]}
    def ask(self,question,online=True):
        if not online:return {'answer':'Для свежего расписания включите поиск по сайтам МГТУ в настройках.','sources':[],'route':'clarify'}
        if self.pending and self.suggestions:
            value=norm(question).strip(' ?!.')
            if value in ['нет','не эта']:
                self.clear();self.awaiting_target=True
                return {'answer':'Уточните название нужной группы.','sources':[],'route':'clarify'}
            if len(self.pending)==1 and value in ['да','покажи','показать','подтверждаю','верно','эту','ее']:
                self.selected=self.pending[0];self.pending=[];self.suggestions=False;self.awaiting_target=False
                return self._answer_selected()
        asked_group=extract_group(question)
        from .people import identify_person
        person=identify_person(question)
        if not asked_group and person and norm(person['name'])==norm(question).strip(' ?!.'):
            self.pending=[];self.selected=None;self.suggestions=False;self.awaiting_target=True
        same_group=not asked_group or any(exact_group(extract_group(item['name']),asked_group) for item in self.pending)
        if self.pending and same_group:
            selection=self._selection(question)
            if selection is not None:
                if not 0<=selection<len(self.pending):return self._options()
                self._update(question);self.selected=self.pending[selection];self.pending=[];self.suggestions=False;self.awaiting_target=False;return self._answer_selected()
            if self._subgroup(question) is not None:return self._options()
        elif self.selected and not asked_group and (subgroup:=self._subgroup(question)) is not None:
            matching=[item for item in self.candidates if self._item_subgroup(item)==subgroup]
            if len(matching)==1:
                self.selected=matching[0];self._update(question);return self._answer_selected()
            return {'answer':'Не нашёл такую подгруппу для выбранной группы. Уточните номер подгруппы.','sources':[],'route':'clarify'}
        group=asked_group;query=group.query() if group else teacher_query(question,bare=self.awaiting_target)
        if query:
            # A group supplied after the bot asks for it keeps the original day.
            self._update(question,reset=not self.awaiting_target);self.selected=None;self.pending=[];self.candidates=[];self.awaiting_target=False;self.suggestions=False
            items=self._lookup(query);subgroup=self._subgroup(question)
            if group:
                # Inspect both plausible Latin readings, including when the
                # first finds a group. Otherwise PIb might silently select РИб.
                for prefix in group.aliases[1:]:
                    alternate=GroupInput(prefix,group.parts,group.compact).query()
                    items.extend(self._lookup(alternate))
                unique={item['url']:item for item in items};items=list(unique.values())
                matched=[item for item in items if group_matches(extract_group(item['name']),group)]
                # One broader retry, at most three HTTP searches in total.
                if not matched and (group.parts or group.compact):
                    broader=GroupInput(group.prefix,parts=group.parts[:1] if group.parts else (),compact=group.compact[:2]).query()
                    if norm(broader)!=norm(query):
                        broad_items=self._lookup(broader)
                        matched=[item for item in broad_items if group_matches(extract_group(item['name']),group)]
                        if not matched:
                            # A real master programme can publish АПИм-25 while
                            # the user supplies АПИм-25-1. Never silently select it.
                            close=[]
                            for item in broad_items:
                                candidate=extract_group(item['name'])
                                asked_year=group.parts[0] if group.parts else group.compact[:2]
                                if candidate and candidate.prefix in group.aliases and candidate.parts and candidate.parts[0]==asked_year:close.append(item)
                            if close:
                                self.pending=close[:8];self.candidates=list(self.pending);self.suggestions=True
                                return self._options()
                exact=[item for item in matched if exact_group(extract_group(item['name']),group)]
                items=exact or matched
            elif not items and ' ' in query:
                items=self._lookup(query.split()[0])
            if not group and items:items=self._match_teacher(items,query)
            self.candidates=list(items)
            if subgroup is not None:items=[item for item in items if self._item_subgroup(item)==subgroup]
            if not items:
                self.pending=[];self.awaiting_target=True;return {'answer':'Не нашёл такой вариант. Напишите точную группу с подгруппой или фамилию преподавателя.','sources':[],'route':'clarify'}
            if len(items)==1:self.selected=items[0];self.pending=[];return self._answer_selected()
            self.pending=items[:25];return self._options()
        self._update(question)
        if self.pending:return self._options()
        if self.selected:return self._answer_selected()
        self.awaiting_target=True;return {'answer':'Для какой группы или преподавателя показать расписание? Например: АВб-26-1-1, 1 подгруппа.','sources':[],'route':'clarify'}
