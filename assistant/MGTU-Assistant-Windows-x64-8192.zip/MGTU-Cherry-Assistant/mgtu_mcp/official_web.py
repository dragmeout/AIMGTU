"""Small adapter for the existing public timetable parser."""
from .web import fetch,WebError
class Client:
    def __init__(self):self.fetched_times={}
    def fetch(self,url,**kwargs):
        p=fetch(url);self.fetched_times[p['url']]=p['fetched_at']
        return p['url'],p['body'],p['headers']
