"""Local, bounded document extraction with real source locators."""
from pathlib import Path
import csv,hashlib,io,json,re,zipfile
from xml.etree import ElementTree as ET

MAX_BYTES=25*1024*1024
SUPPORTED={'.docx','.pdf','.txt','.md','.markdown','.csv','.html','.htm','.json','.xml','.rss'}
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
W='{'+NS['w']+'}'

class DocumentError(ValueError):pass

def clean(text):return re.sub(r'[ \t\u00a0]+',' ',str(text)).strip()
def xml(raw):
    if re.search(br'<!\s*(?:DOCTYPE|ENTITY)',raw,re.I):raise DocumentError('XML с DTD и внешними сущностями не поддерживается.')
    return ET.fromstring(raw)
def paragraph(node):
    parts=[]
    for e in node.iter():
        tag=e.tag.rsplit('}',1)[-1]
        if tag=='t':parts.append(e.text or '')
        elif tag=='tab':parts.append('\t')
        elif tag in ['br','cr']:parts.append('\n')
    return clean(''.join(parts))

def docx(raw):
    metadata={};blocks=[];sections=[];counter=0;table_number=0
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        if sum(i.file_size for i in z.infolist())>80*1024*1024:raise DocumentError('Слишком большой распакованный DOCX.')
        def part(name,limit=20*1024*1024):
            i=z.getinfo(name)
            if i.file_size>limit:raise DocumentError('Слишком большой раздел DOCX.')
            return xml(z.read(name))
        if 'docProps/core.xml' in z.namelist():
            for e in part('docProps/core.xml',1024*1024):
                if e.text:metadata[e.tag.rsplit('}',1)[-1]]=e.text
        styles={}
        if 'word/styles.xml' in z.namelist():
            for s in part('word/styles.xml').findall('w:style',NS):
                ident=s.get(W+'styleId');level=s.find('w:pPr/w:outlineLvl',NS);name=s.find('w:name',NS)
                if level is not None:styles[ident]=int(level.get(W+'val','0'))+1
                elif name is not None:
                    m=re.search(r'(?:heading|заголовок)\s*(\d)',name.get(W+'val',''),re.I)
                    if m:styles[ident]=int(m[1])
        body=part('word/document.xml').find('w:body',NS)
        if body is None:raise DocumentError('В DOCX нет основного текста.')
        for node in body:
            if node.tag==W+'p':
                counter+=1;text=paragraph(node)
                if not text:continue
                style=node.find('w:pPr/w:pStyle',NS);level=styles.get(style.get(W+'val')) if style is not None else None
                direct=node.find('w:pPr/w:outlineLvl',NS)
                if direct is not None:level=int(direct.get(W+'val','0'))+1
                if level:
                    sections=sections[:level-1];sections.append(text)
                num=node.find('w:pPr/w:numPr',NS)
                blocks.append({'kind':'heading' if level else ('list_item' if num is not None else 'paragraph'),
                    'text':text,'section':list(sections),'heading_level':level,'paragraph':counter,'page':None,
                    'locator':' → '.join(sections)+f' · абзац {counter}' if sections else f'Абзац {counter}'})
            elif node.tag==W+'tbl':
                table_number+=1;rows=[];carry={}
                for rn,tr in enumerate(node.findall('w:tr',NS),1):
                    cells=[];grid=[];col=0;continues=[]
                    for tc in tr.findall('w:tc',NS):
                        span=tc.find('w:tcPr/w:gridSpan',NS);width=int(span.get(W+'val','1')) if span is not None else 1
                        merged=tc.find('w:tcPr/w:vMerge',NS);continued=merged is not None and merged.get(W+'val')!='restart'
                        value='\n'.join(t for p in tc.findall('w:p',NS) if (t:=paragraph(p)))
                        if continued and not value:value=carry.get(col,'')
                        if merged is not None:carry[col]=value
                        else:carry.pop(col,None)
                        cells.append(value);grid.append(width);continues.append(continued);col+=width
                    rows.append({'row':rn,'cells':cells,'grid_spans':grid,'vertical_continuations':continues})
                header_rows=sum(tr.find('w:trPr/w:tblHeader',NS) is not None for tr in node.findall('w:tr',NS))
                table={'number':table_number,'rows':rows,'declared_header_rows':header_rows,'first_row_header_inferred':header_rows==0}
                text='\n'.join(f"Строка {r['row']}: "+' | '.join(r['cells']) for r in rows)
                blocks.append({'kind':'table','text':text,'section':list(sections),'table':table,'page':None,
                    'locator':(' → '.join(sections)+' · ' if sections else '')+f'Таблица {table_number}'})
    return metadata,blocks

def text_decode(raw):
    if b'\x00' in raw[:4096] and not raw.startswith((b'\xff\xfe',b'\xfe\xff')):raise DocumentError('Файл содержит двоичные данные.')
    for encoding in ['utf-8-sig','utf-16' if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else 'cp1251']:
        try:return raw.decode(encoding)
        except UnicodeError:pass
    raise DocumentError('Не удалось определить кодировку текста.')

def html_document(raw):
    from bs4 import BeautifulSoup
    soup=BeautifulSoup(raw,'html.parser')
    title=soup.title.get_text(' ',strip=True) if soup.title else ''
    for node in soup.select('script,style,nav,header,footer,aside,form,[hidden],noscript'):node.decompose()
    root=soup.select_one('article') or soup.select_one('.item-page') or soup.select_one('main') or soup.body or soup
    blocks=[];section=[];seen=set();table_number=0
    for node in root.find_all(['h1','h2','h3','h4','h5','h6','p','li','table','div']):
        if node.find_parent('table'):continue
        if node.name=='div' and node.find(['p','li','div','table']):continue
        text=clean(node.get_text(' ',strip=True))
        if not text or text in seen:continue
        seen.add(text)
        if node.name.startswith('h') and node.name[1:].isdigit():
            level=int(node.name[1:]);section=section[:level-1];section.append(text)
        if node.name=='table':
            table_number+=1;rows=[]
            for rn,row in enumerate(node.find_all('tr'),1):
                cells=[clean(c.get_text(' ',strip=True)) for c in row.find_all(['th','td'],recursive=False)]
                if cells:rows.append({'row':rn,'cells':cells})
            table={'number':table_number,'rows':rows,'declared_header_rows':0,'first_row_header_inferred':True}
            text='\n'.join(f"Строка {r['row']}: "+' | '.join(r['cells']) for r in rows)
            blocks.append({'kind':'table','text':text,'section':list(section),'table':table,'page':None,'locator':f'Таблица {table_number}'})
        else:blocks.append({'kind':'heading' if node.name.startswith('h') else 'paragraph','text':text,'section':list(section),'page':None,'locator':' → '.join(section) or f'Блок {len(blocks)+1}'})
    if not blocks:
        text=clean(root.get_text(' ',strip=True))
        if text:blocks=[{'kind':'paragraph','text':text,'section':[],'page':None,'locator':'Основной текст'}]
    return {'title':title},blocks

def parse_document(path):
    path=Path(path)
    if path.suffix.lower() not in SUPPORTED:raise DocumentError('Неподдерживаемый формат. Доступны DOCX, PDF с текстом, TXT, Markdown, CSV, HTML, JSON и XML.')
    if path.stat().st_size>MAX_BYTES:raise DocumentError('Файл больше 25 МиБ. Разделите его на части.')
    raw=path.read_bytes();ext=path.suffix.lower();metadata={};blocks=[]
    try:
        if path.name.endswith('.archive.json'):
            item=json.loads(raw)
            if item.get('schema')!='mgtu-archive-1':raise DocumentError('Неверный формат архивного документа.')
            return {**item,'filename':item.get('filename',path.name),'sha256':hashlib.sha256(raw).hexdigest(),'untrusted_content':True}
        if ext=='.docx':metadata,blocks=docx(raw)
        elif ext=='.pdf':
            from pypdf import PdfReader
            reader=PdfReader(io.BytesIO(raw))
            if reader.is_encrypted and not reader.decrypt(''):raise DocumentError('PDF защищён паролем. Сначала сохраните доступную копию.')
            if len(reader.pages)>300:raise DocumentError('В PDF больше 300 страниц. Разделите его на части.')
            empty=[]
            for pn,page in enumerate(reader.pages,1):
                text=(page.extract_text() or '').strip()
                if text:blocks.append({'kind':'paragraph','text':text,'section':[],'page':pn,'locator':f'Страница {pn}'})
                else:empty.append(pn)
            if empty:metadata['pages_requiring_ocr']=empty
            if reader.metadata:metadata.update({str(k).strip('/'):str(v) for k,v in reader.metadata.items()})
            if not blocks:raise DocumentError('В PDF нет текстового слоя. Требуется OCR; в этот комплект распознавание сканов не включено.')
        elif ext in ['.html','.htm']:metadata,blocks=html_document(raw)
        elif ext=='.csv':
            text=text_decode(raw)
            try:dialect=csv.Sniffer().sniff(text[:8192],delimiters=',;\t|')
            except csv.Error:dialect=csv.excel
            rows=[{'row':i,'cells':r} for i,r in enumerate(csv.reader(io.StringIO(text),dialect),1)]
            blocks=[{'kind':'table','text':'\n'.join(f"Запись {r['row']}: "+' | '.join(r['cells']) for r in rows),'section':[],'page':None,'locator':'CSV таблица','table':{'number':1,'rows':rows,'declared_header_rows':0,'first_row_header_inferred':True}}]
        elif ext=='.json':
            text=json.dumps(json.loads(text_decode(raw)),ensure_ascii=False,indent=2)
            blocks=[{'kind':'data','text':text,'section':[],'page':None,'locator':'JSON'}]
        elif ext in ['.xml','.rss']:
            root=xml(raw);text='\n'.join(f'{e.tag.rsplit("}",1)[-1]}: {clean(e.text)}' for e in root.iter() if e.text and e.text.strip())
            blocks=[{'kind':'data','text':text,'section':[],'page':None,'locator':'XML/RSS'}]
        else:
            text=text_decode(raw);sections=[]
            for line_number,line in enumerate(text.splitlines(),1):
                if not line.strip():continue
                heading=re.match(r'^(#{1,6})\s+(.+)',line) if ext in ['.md','.markdown'] else None
                if heading:sections=sections[:len(heading[1])-1];sections.append(heading[2].strip())
                blocks.append({'kind':'heading' if heading else 'paragraph','text':line,'section':list(sections),'page':None,'line':line_number,'locator':(' → '.join(sections)+' · ' if sections else '')+f'Строка {line_number}'})
    except DocumentError:raise
    except (zipfile.BadZipFile,ET.ParseError,UnicodeError,json.JSONDecodeError,ValueError) as error:
        raise DocumentError('Не удалось разобрать документ: файл повреждён или имеет неверный формат.') from error
    if not any(b['text'].strip() for b in blocks):raise DocumentError('Документ не содержит доступного текста.')
    return {'filename':path.name,'title':metadata.get('title') or metadata.get('Title') or path.stem,'format':ext.lstrip('.'),
            'sha256':hashlib.sha256(raw).hexdigest(),'metadata':metadata,'blocks':blocks,'untrusted_content':True,
            'page_policy':'DOCX не имеет достоверных номеров страниц; используются разделы, абзацы и таблицы.' if ext=='.docx' else 'Страницы указываются только для PDF.'}

def block_chunks(document,limit=2000,overlap=180):
    chunks=[]
    for block in document['blocks']:
        pieces=[]
        if block.get('table'):
            rows=block['table']['rows'];header=' | '.join(rows[0]['cells']) if rows else ''
            for row in rows:
                text=(f'Контекст первой строки: {header}\n' if row['row']>1 else '')+f"Строка {row['row']}: "+' | '.join(row['cells'])
                pieces.append((text,block['locator']+f", строка {row['row']}"))
        else:pieces=[(block['text'],block['locator'])]
        for text,locator in pieces:
            for start in range(0,len(text),max(1,limit-overlap)):
                part=text[start:start+limit]
                if not part.strip():continue
                chunks.append({'text':part,'locator':locator,'page':block.get('page'),'section':block.get('section',[]),
                               'filename':document['filename'],'citation':f"{document['filename']} — {locator}"})
                if start+limit>=len(text):break
    # Combine nearby small paragraphs, retaining both exact source locators.
    merged=[]
    for c in chunks:
        if merged and len(merged[-1]['text'])+len(c['text'])<limit and merged[-1]['section']==c['section'] and merged[-1]['page']==c['page'] and 'Таблица' not in c['locator'] and 'Таблица' not in merged[-1]['locator']:
            merged[-1]['text']+='\n'+c['text'];merged[-1]['citation']+='; '+c['locator']
        else:merged.append(c)
    return merged
