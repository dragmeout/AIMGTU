"""Project-scoped local embeddings, SQLite persistence and attachment bridge."""
from pathlib import Path
from array import array
from contextlib import contextmanager,closing
import hashlib,json,math,os,re,sqlite3,sys,threading,time,urllib.request
from .documents import parse_document,block_chunks,SUPPORTED,DocumentError

ROOT=Path(os.environ.get('MGTU_ROOT',Path(__file__).resolve().parents[1])).resolve()
PROJECT=os.environ.get('MGTU_PROJECT','mgtu')
if not re.fullmatch(r'[a-zA-Z0-9_-]{1,50}',PROJECT):raise ValueError('Invalid project identifier')
PROJECT_ROOT=ROOT/'data/projects'/PROJECT
DOCUMENTS=PROJECT_ROOT/'documents'
INDEX=PROJECT_ROOT/'index.sqlite'
LOCK=threading.RLock()
PARSER_VERSION='1.0.0'

def config():
    p=ROOT/'data/config.json'
    return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'ollama_url':'http://127.0.0.1:11439','embedding_model':'qwen3-embedding:0.6b','cherry_profile':'runtime/cherry/data'}

def ollama(path,body=None,timeout=120):
    base=config()['ollama_url'].rstrip('/')
    if not re.fullmatch(r'http://127\.0\.0\.1:\d{4,5}',base):raise RuntimeError('Ollama должна быть доступна только на локальном адресе 127.0.0.1.')
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    data=None if body is None else json.dumps(body,ensure_ascii=False).encode('utf-8')
    request=urllib.request.Request(base+path,data=data,headers={'Content-Type':'application/json'})
    try:
        with opener.open(request,timeout=timeout) as response:return json.load(response)
    except Exception as error:raise RuntimeError('Ollama недоступна или модель не загружена. Запустите комплект и выполните диагностику.') from error

def embed(texts,query=False):
    if not texts:return []
    inputs=['Instruct: Given a question, retrieve relevant university documents.\nQuery: '+t if query else t for t in texts]
    result=ollama('/api/embed',{'model':config()['embedding_model'],'input':inputs,'truncate':False,'keep_alive':-1,'options':{'num_ctx':8192}})
    vectors=result.get('embeddings',[])
    if len(vectors)!=len(texts) or not vectors:raise RuntimeError('Модель вернула неверное число эмбеддингов.')
    for v in vectors:
        if not v or not all(math.isfinite(x) for x in v):raise RuntimeError('Модель вернула некорректный эмбеддинг.')
        norm=math.sqrt(sum(x*x for x in v)) or 1
        for i in range(len(v)):v[i]/=norm
    return vectors

@contextmanager
def connect():
    PROJECT_ROOT.mkdir(parents=True,exist_ok=True);DOCUMENTS.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(INDEX,timeout=30)
    db.execute('PRAGMA journal_mode=WAL')
    db.executescript('''CREATE TABLE IF NOT EXISTS documents(path TEXT PRIMARY KEY,signature TEXT,metadata TEXT,status TEXT,error TEXT);
    CREATE TABLE IF NOT EXISTS chunks(id INTEGER PRIMARY KEY,path TEXT,content TEXT,metadata TEXT,embedding BLOB);
    CREATE INDEX IF NOT EXISTS chunks_path ON chunks(path);
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);''')
    try:
        with db:yield db
    finally:db.close()

def source_metadata(path):
    p=PROJECT_ROOT/'sources'/((hashlib.sha256(path.relative_to(DOCUMENTS).as_posix().encode()).hexdigest())+'.json')
    return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}

def synchronize(force=False):
    with LOCK,connect() as db:
        model=config()['embedding_model']
        tags=ollama('/api/tags')['models'];digest=next((m['digest'] for m in tags if m['name']==model),None)
        if not digest:raise RuntimeError('Модель эмбеддингов не установлена. Выполните setup.')
        version=model+'|'+digest+'|'+PARSER_VERSION
        old=db.execute('SELECT value FROM settings WHERE key=?',('embedding',)).fetchone()
        if force or (old and old[0]!=version):db.execute('DELETE FROM chunks');db.execute('DELETE FROM documents')
        files=[]
        for path in DOCUMENTS.rglob('*'):
            if path.is_file() and path.suffix.lower() in SUPPORTED and DOCUMENTS.resolve() in path.resolve().parents:files.append(path)
        seen={p.relative_to(DOCUMENTS).as_posix() for p in files}
        deleted=[r[0] for r in db.execute('SELECT path FROM documents') if r[0] not in seen]
        for rel in deleted:db.execute('DELETE FROM chunks WHERE path=?',(rel,));db.execute('DELETE FROM documents WHERE path=?',(rel,))
        updated=0;errors=[]
        for path in sorted(files):
            rel=path.relative_to(DOCUMENTS).as_posix();stat=path.stat()
            with path.open('rb') as source_file:content_hash=hashlib.file_digest(source_file,'sha256').hexdigest()
            signature=f'{stat.st_size}:{content_hash}'
            row=db.execute('SELECT signature,status,metadata FROM documents WHERE path=?',(rel,)).fetchone()
            source=source_metadata(path);source_version=hashlib.sha256(json.dumps(source,sort_keys=True).encode()).hexdigest()
            if row and row[1]=='ready' and (row[0]==signature or json.loads(row[2]).get('sha256')==content_hash):
                db.execute('UPDATE documents SET signature=? WHERE path=?',(signature,rel))
                existing=json.loads(row[2])
                if existing.get('source_version')!=source_version:
                    revised={**existing,**source,'source_version':source_version}
                    for cid,m in db.execute('SELECT id,metadata FROM chunks WHERE path=?',(rel,)).fetchall():
                        c=json.loads(m);c.update(source);c['source_version']=source_version
                        db.execute('UPDATE chunks SET metadata=? WHERE id=?',(json.dumps(c,ensure_ascii=False),cid))
                    db.execute('UPDATE documents SET metadata=? WHERE path=?',(json.dumps(revised,ensure_ascii=False),rel));db.commit()
                continue
            # Never use stale text after a file has changed, even if re-indexing fails.
            db.execute('DELETE FROM chunks WHERE path=?',(rel,))
            try:
                document=parse_document(path);meta={**source,'source_version':source_version,'filename':document['filename'],'title':source.get('title') or document['title'],
                    'sha256':document['sha256'],'file_metadata':document.get('metadata',{}),'project':PROJECT,'path':rel,'format':document['format']}
                if document.get('source'):meta['source']=document['source']
                pieces=block_chunks(document)
                for start in range(0,len(pieces),8):
                    batch=pieces[start:start+8];vectors=embed([document['title']+'\n'+c['text'] for c in batch])
                    for c,v in zip(batch,vectors):
                        buf=array('f',v)
                        if sys.byteorder!='little':buf.byteswap()
                        db.execute('INSERT INTO chunks(path,content,metadata,embedding) VALUES(?,?,?,?)',(rel,c['text'],json.dumps({**meta,**c},ensure_ascii=False),buf.tobytes()))
                db.execute('INSERT OR REPLACE INTO documents VALUES(?,?,?,?,?)',(rel,signature,json.dumps(meta,ensure_ascii=False),'ready',''));updated+=1
            except DocumentError as error:
                db.execute('INSERT OR REPLACE INTO documents VALUES(?,?,?,?,?)',(rel,signature,json.dumps({'filename':path.name},ensure_ascii=False),'error',str(error)));errors.append({'file':path.name,'error':str(error)})
            except Exception:
                db.execute('DELETE FROM chunks WHERE path=?',(rel,));db.execute('INSERT OR REPLACE INTO documents VALUES(?,?,?,?,?)',(rel,signature,'{}','pending','Требуется повторная индексация.'));db.commit();raise
            db.commit()
        db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',('embedding',version));db.commit()
        count=db.execute('SELECT count(*) FROM chunks').fetchone()[0]
        return {'project':PROJECT,'documents':len(files),'chunks':count,'updated':updated,'deleted':len(deleted),'errors':errors}

def search_documents(query,limit=5):
    query=' '.join(str(query).split())
    if not query or len(query)>1500:raise DocumentError('Уточните поисковый вопрос: от 1 до 1500 символов.')
    state=synchronize();vector=embed([query],query=True)[0];words=re.findall(r'[а-яёa-z0-9]{4,}',query.casefold());results=[]
    with LOCK,connect() as db:
        for cid,text,metadata,blob in db.execute('SELECT id,content,metadata,embedding FROM chunks'):
            v=array('f');v.frombytes(blob)
            if sys.byteorder!='little':v.byteswap()
            if len(v)!=len(vector):raise RuntimeError('Размерность индекса изменилась. Выполните перестроение базы.')
            meta=json.loads(metadata);score=sum(a*b for a,b in zip(v,vector));lex=sum(w in text.casefold() for w in words)/max(1,len(words))
            status=meta.get('file_metadata',{}).get('allowed_use','')
            penalty=.12 if 'dated_reference' in status or 'unsigned_template' in meta.get('status','') else 0
            citation=meta.get('title',meta['filename'])+' — '+meta.get('citation','')
            results.append((score+.10*lex-penalty,{'chunk_id':cid,**meta,'citation':citation,'text':text,'score':round(score,4),'origin':'document','untrusted_content':True}))
    results.sort(key=lambda item:-item[0]);selected=[];per_doc={}
    for _,r in results:
        if per_doc.get(r['path'],0)>=2:continue
        selected.append(r);per_doc[r['path']]=per_doc.get(r['path'],0)+1
        if len(selected)>=max(1,min(int(limit),8)):break
    return {'project':PROJECT,'query':query,'results':selected,'index':state,'note':'Ссылайтесь на filename и citation. Архивные материалы не подтверждают текущие правила.'}

def attachment_candidates(name):
    # Read-only bridge for Cherry Studio 2.1.10. No chat history or providers are read.
    profile=(ROOT/config().get('cherry_profile','runtime/cherry/data')).resolve()
    if ROOT not in profile.parents:return []
    database=profile/'Data/cherrystudio.sqlite'
    if not database.exists():return []
    matches=[]
    with closing(sqlite3.connect(database.as_uri()+'?mode=ro',uri=True,timeout=5)) as db:
        columns={r[1] for r in db.execute('PRAGMA table_info(file_entry)')}
        if not {'id','name','ext','origin'}<=columns:return []
        deleted=' WHERE deleted_at IS NULL' if 'deleted_at' in columns else ''
        for ident,stem,ext,origin in db.execute('SELECT id,name,ext,origin FROM file_entry'+deleted):
            if origin!='internal':continue
            filename=stem+('.'+ext if ext else '')
            handle='file_'+hashlib.sha256(ident.encode()).hexdigest()[:16]
            if name not in [filename,ident,handle]:continue
            path=profile/'Data/Files'/(ident+('.'+ext if ext else ''))
            if path.is_file():matches.append({'path':path,'name':filename,'id':ident,'handle':handle})
    # Reattaching the exact same bytes under the same name is unambiguous.
    # Different contents with a shared name still require an explicit handle.
    unique=[];seen=set()
    for match in matches:
        key=(match['name'],hashlib.sha256(match['path'].read_bytes()).hexdigest())
        if key not in seen:seen.add(key);unique.append(match)
    return unique

def resolve_document(name):
    rel=Path(str(name))
    direct=(DOCUMENTS/rel).resolve()
    if DOCUMENTS.resolve() in direct.parents and direct.is_file():return direct,None
    matches=[p for p in DOCUMENTS.rglob('*') if p.is_file() and p.name==name and DOCUMENTS.resolve() in p.resolve().parents]
    attachments=attachment_candidates(str(name))
    if len(matches)+len(attachments)>1:raise DocumentError('Найдено несколько файлов с таким именем. Укажите относительный путь в проекте или идентификатор вложения.')
    if matches:return matches[0],None
    if attachments:return attachments[0]['path'],attachments[0]['name']
    raise DocumentError('Файл не найден в этом проекте или среди его вложений Cherry Studio. Прикрепите файл к чату либо скопируйте его в папку documents проекта.')

def read_document(name,section='',max_chars=14000,start_block=0):
    path,original_name=resolve_document(name);document=parse_document(path)
    if original_name:
        document['filename']=original_name
        if document['title']==path.stem:document['title']=Path(original_name).stem
    blocks=[b for b in document['blocks'] if not section or section.casefold() in (' '.join(b.get('section',[]))+' '+b['locator']).casefold()]
    max_chars=max(1000,min(int(max_chars),16000));selected=[];used=0
    for b in blocks[max(0,int(start_block)):]:
        if used+len(b['text'])>max_chars:
            if not selected:selected.append({**b,'text':b['text'][:max_chars],'block_truncated':True})
            break
        selected.append(b);used+=len(b['text'])
    return {**document,'blocks':selected,'total_blocks':len(document['blocks']),'returned_blocks':len(selected),'truncated':len(selected)<len(blocks),
            'outline':[{'block':i,'kind':b['kind'],'locator':b['locator']} for i,b in enumerate(document['blocks']) if b['kind'] in ['heading','table']][:150],
            'project':PROJECT,'origin':'attachment' if original_name else 'document','note':'Для DOCX используйте раздел, абзац или таблицу; номера страниц DOCX не определены.'}

def search_document(name,query,limit=4):
    """Search only the explicitly named attachment; never pool unrelated chat files."""
    path,original_name=resolve_document(name);document=parse_document(path)
    if original_name:document['filename']=original_name
    pieces=block_chunks(document);limit=max(1,min(int(limit),6))
    # Content-addressed, per-file cache; file must still exist before accessing it.
    digest=next(m['digest'] for m in ollama('/api/tags')['models'] if m['name']==config()['embedding_model'])
    key=hashlib.sha256((document['sha256']+digest+PARSER_VERSION).encode()).hexdigest()
    cache=PROJECT_ROOT/'attachment-cache';cache.mkdir(parents=True,exist_ok=True)
    cached=cache/(key+'.json')
    if cached.exists():vectors=json.loads(cached.read_text(encoding='utf-8'))
    else:
        vectors=[]
        for start in range(0,len(pieces),8):vectors.extend(embed([p['text'] for p in pieces[start:start+8]]))
        temporary=cached.with_suffix('.tmp');temporary.write_text(json.dumps(vectors),encoding='utf-8');temporary.replace(cached)
    q=embed([str(query)[:1500]],query=True)[0]
    ranked=sorted(zip(pieces,vectors),key=lambda p:-sum(a*b for a,b in zip(q,p[1])))
    return {'filename':document['filename'],'results':[p for p,v in ranked[:limit]],'origin':'attachment' if original_name else 'document','untrusted_content':True}
