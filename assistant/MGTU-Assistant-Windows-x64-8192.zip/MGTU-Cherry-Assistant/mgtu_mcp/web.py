"""Bounded public-web tools: DNS pinning, redirect checks, no ambient credentials."""
from datetime import datetime,timezone
import gzip,http.client,ipaddress,json,re,socket,ssl,time,zlib
from urllib.parse import quote,unquote,urljoin,urlsplit,urlunsplit,urlencode
from xml.etree import ElementTree as ET
from .documents import html_document,xml

UA='MGTU-Local-Assistant/1.0 (public information; bounded read-only requests)'
class WebError(RuntimeError):pass

def official(url):
    host=(urlsplit(url).hostname or '').lower().rstrip('.')
    return host=='magtu.ru' or host.endswith('.magtu.ru')

def safe_target(url):
    if len(url)>2500 or re.search(r'[\x00-\x20\\]',url):raise WebError('Некорректный адрес страницы.')
    p=urlsplit(url)
    if p.scheme not in ['https','http'] or p.username or p.password or not p.hostname:raise WebError('Разрешены только публичные HTTP/HTTPS-адреса без учётных данных.')
    host=p.hostname.rstrip('.').encode('idna').decode('ascii')
    if host.lower() in ['localhost','localhost.localdomain'] or host.lower().endswith(('.local','.internal','.localhost')):raise WebError('Служебные адреса недоступны веб-инструментам.')
    port=p.port or (443 if p.scheme=='https' else 80)
    if port not in [80,443]:raise WebError('Разрешены только стандартные веб-порты 80 и 443.')
    if re.search(r'[\x00-\x1f]',unquote(p.path+p.query)):raise WebError('Управляющие символы в адресе запрещены.')
    try:addresses=socket.getaddrinfo(host,port,type=socket.SOCK_STREAM)
    except OSError as error:raise WebError('Не удалось определить адрес сайта.') from error
    ips=list(dict.fromkeys(a[4][0] for a in addresses))
    if not ips or any(not ipaddress.ip_address(ip.split('%')[0]).is_global for ip in ips):raise WebError('Локальные, частные и служебные IP-адреса запрещены.')
    target=quote(p.path or '/',safe='/%:@!$&\'()*+,;=-._~')+('?' + quote(p.query,safe='=&?/:@!$\'()*+,;%-._~') if p.query else '')
    return p.scheme,host,port,ips,target

def fetch(url,max_bytes=3_000_000,timeout=22,brave_key=None):
    start=time.monotonic();history=[]
    for _ in range(6):
        scheme,host,port,ips,target=safe_target(url)
        if time.monotonic()-start>timeout:raise WebError('Истекло время ожидания сайта.')
        connection=http.client.HTTPConnection(host,port,timeout=min(10,timeout))
        last_error=None
        for ip in ips:
            try:
                sock=socket.create_connection((ip,port),timeout=min(8,timeout))
                if scheme=='https':sock=ssl.create_default_context().wrap_socket(sock,server_hostname=host)
                sock.settimeout(min(12,max(1,timeout-(time.monotonic()-start))))
                connection.sock=sock;break
            except OSError as error:last_error=error
        else:raise WebError('Не удалось подключиться к сайту.') from last_error
        try:
            request_headers={'Host':host,'User-Agent':UA,'Accept':'text/html,application/json,application/xml,application/pdf,*/*;q=0.5','Accept-Encoding':'identity','Connection':'close'}
            if brave_key and host=='api.search.brave.com' and not history:request_headers['X-Subscription-Token']=brave_key
            connection.request('GET',target,headers=request_headers)
            response=connection.getresponse();headers={k.lower():v for k,v in response.getheaders()}
            if response.status in [301,302,303,307,308]:
                if not headers.get('location'):raise WebError('Сайт прислал перенаправление без адреса.')
                history.append(url);url=urljoin(url,headers['location']);continue
            if response.status!=200:raise WebError(f'Сайт вернул HTTP {response.status}.')
            try:declared=int(headers.get('content-length','0'))
            except ValueError:declared=0
            if declared>max_bytes:raise WebError('Размер загрузки превышает установленный предел.')
            raw=bytearray()
            while True:
                if time.monotonic()-start>timeout:raise WebError('Истекло время загрузки страницы.')
                part=response.read(min(65536,max_bytes+1-len(raw)))
                if not part:break
                raw.extend(part)
                if len(raw)>max_bytes:raise WebError('Размер загрузки превышает установленный предел.')
            raw=bytes(raw)
            if headers.get('content-encoding','').lower() in ['gzip','deflate']:
                mode=16+zlib.MAX_WBITS if headers['content-encoding'].lower()=='gzip' else zlib.MAX_WBITS
                decoder=zlib.decompressobj(mode);raw=decoder.decompress(raw,max_bytes+1)
                if len(raw)>max_bytes or not decoder.eof:raise WebError('Распакованная страница слишком велика.')
            public_headers={k:v for k,v in headers.items() if k in ['content-type','content-disposition','last-modified','etag']}
            return {'url':url,'body':raw,'headers':public_headers,'fetched_at':datetime.now(timezone.utc).isoformat(),'redirects':history,'official_mgtu':official(url)}
        except (OSError,http.client.HTTPException) as error:raise WebError('Ошибка соединения с сайтом. Повторите запрос позже.') from error
        finally:connection.close()
    raise WebError('Слишком много перенаправлений.')

def links_from_search(raw,base):
    from bs4 import BeautifulSoup
    soup=BeautifulSoup(raw,'html.parser');links=[];seen=set()
    for a in soup.select('dt.result-title a,.result-title a,.search-results dt a,.search-results h3 a,.entry-title a'):
        url=urljoin(base,a.get('href',''))
        if urlsplit(url).scheme not in ['https','http'] or url in seen:continue
        seen.add(url);links.append({'title':a.get_text(' ',strip=True),'url':url,'official_mgtu':official(url)})
    return links

def rss_items(raw):
    root=xml(raw);result=[]
    for item in root.findall('.//item'):
        result.append({'title':item.findtext('title',''),'url':item.findtext('link',''),'description':item.findtext('description','')[:600],
                       'date':item.findtext('pubDate',''),'official_mgtu':official(item.findtext('link',''))})
    return result

def web_search(query,limit=6,provider='auto'):
    query=' '.join(str(query).split())
    if not 2<=len(query)<=220:raise WebError('Поисковый запрос должен содержать от 2 до 220 символов.')
    limit=max(1,min(int(limit),10));results=[];errors=[];seen=set()
    curated=[(r'ректор|руководств|проректор','Руководство МГТУ','https://www.magtu.ru/sveden/managers.html'),
             (r'стипенд|материальн','Стипендии и меры поддержки','https://www.magtu.ru/sveden/grants.html'),
             (r'правил|положени|документ','Официальные документы МГТУ','https://www.magtu.ru/sveden/document.html')]
    for pattern,title,url in curated:
        if re.search(pattern,query,re.I):results.append({'title':title,'url':url,'official_mgtu':True,'curated':True})
    # Official university search comes first, including older faculty pages.
    if provider in ['auto','magtu']:
        endpoint='https://www.magtu.ru/servisy-sajta/poisk-po-sajtu.html?'+urlencode({'searchword':query,'searchphrase':'all','ordering':'alpha','limit':'30'})
        try:
            page=fetch(endpoint);results.extend(links_from_search(page['body'],page['url']))
        except Exception as error:errors.append('Поиск МГТУ: '+str(error))
    if provider!='magtu' and (len(results)<limit or provider in ['bing','brave']):
        import os
        key=os.environ.get('BRAVE_SEARCH_API_KEY','')
        try:
            if provider=='brave':
                if not key:raise WebError('Для Brave задайте BRAVE_SEARCH_API_KEY. Бесплатный поиск Bing доступен без ключа.')
                page=fetch('https://api.search.brave.com/res/v1/web/search?'+urlencode({'q':query,'count':10}),brave_key=key)
                results.extend({'title':r['title'],'url':r['url'],'description':r.get('description','')[:600],'official_mgtu':official(r['url'])} for r in json.loads(page['body']).get('web',{}).get('results',[]))
            else:
                page=fetch('https://www.bing.com/search?'+urlencode({'format':'rss','q':query,'count':'10'}));results.extend(rss_items(page['body']))
        except Exception as error:errors.append('Внешний поиск: '+str(error))
    words=[w.casefold() for w in re.findall(r'[\w-]{3,}',query)]
    def rank(r):
        text=(r['title']+' '+r['url']).casefold();score=sum(w in text for w in words)
        if r['official_mgtu']:score+=10
        if r.get('curated'):score+=25
        if any(w in text for w in ['/staff/','состав-кафедры','sostav-kafedr','/sveden/']):score+=4
        return (not r['official_mgtu'],-score)
    unique=[]
    for r in sorted(results,key=rank):
        if r['url'] not in seen:
            seen.add(r['url']);unique.append(r)
    return {'query':query,'results':unique[:limit],'errors':errors,'fetched_at':datetime.now(timezone.utc).isoformat(),
            'note':'Результаты поиска — указатели. Для ответа по фактам нужно загрузить соответствующую страницу.'}

def fetch_page(url):
    page=fetch(url);raw=page.pop('body');ctype=page['headers'].get('content-type','').lower()
    if raw.startswith((b'%PDF',b'PK')) or 'application/pdf' in ctype or 'wordprocessingml' in ctype:
        raise WebError('Это PDF или DOCX. Используйте download_document, затем read_document по возвращённому имени файла.')
    if 'json' in ctype or raw.lstrip().startswith((b'{',b'[')):
        try:page.update(kind='json',data=json.loads(raw),text=raw.decode('utf-8')[:14000]);return page
        except (ValueError,UnicodeError):pass
    if 'xml' in ctype or 'rss' in ctype or raw.lstrip().startswith(b'<?xml'):
        root=xml(raw);page.update(kind='xml',items=rss_items(raw),text='\n'.join(e.text.strip() for e in root.iter() if e.text and e.text.strip())[:14000]);return page
    metadata,blocks=html_document(raw)
    page.update(kind='html',title=metadata.get('title',''),text='\n'.join(b['text'] for b in blocks)[:16000],untrusted_content=True)
    return page
