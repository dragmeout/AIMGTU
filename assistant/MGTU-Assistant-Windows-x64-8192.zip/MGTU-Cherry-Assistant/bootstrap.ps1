﻿param([ValidateSet('setup','start','stop','doctor','backup','index','import-provider','import-tools','offline','online')][string]$Action='start')
$ErrorActionPreference='Stop'
$kitRoot=$PSScriptRoot
$pythonPath=Join-Path $kitRoot 'runtime/python/python.exe'
if(-not (Test-Path -LiteralPath $pythonPath)) {
    if($Action -ne 'setup'){throw 'Сначала запустите setup.cmd'}
    $architecture=if(($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') -or ($env:PROCESSOR_ARCHITEW6432 -eq 'ARM64')){'arm64'}else{'64'}
    $lockedAssets=Get-Content -LiteralPath (Join-Path $kitRoot 'additional-assets.lock.json') -Raw | ConvertFrom-Json
    $pythonAsset=$lockedAssets | Where-Object {$_.role -eq "python-windows-$architecture"} | Select-Object -First 1
    if(-not $pythonAsset){throw 'Нет подходящего проверенного Python в манифесте'}
    $downloadDirectory=Join-Path $kitRoot '.cache/downloads';New-Item -ItemType Directory -Path $downloadDirectory -Force | Out-Null
    $archive=Join-Path $downloadDirectory $pythonAsset.name
    if((-not (Test-Path -LiteralPath $archive)) -or ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLower() -ne $pythonAsset.sha256)) {
        Invoke-WebRequest -Uri $pythonAsset.url -OutFile ($archive+'.part') -UseBasicParsing
        if((Get-FileHash -LiteralPath ($archive+'.part') -Algorithm SHA256).Hash.ToLower() -ne $pythonAsset.sha256){throw 'Контрольная сумма Python не совпала'}
        Move-Item -LiteralPath ($archive+'.part') -Destination $archive -Force
    }
    Expand-Archive -LiteralPath $archive -DestinationPath (Split-Path -Parent $pythonPath) -Force
}
$env:PYTHONUTF8='1'
if($Action -eq 'setup') {
    & $pythonPath -m pip install --disable-pip-version-check -r (Join-Path $kitRoot 'requirements.txt')
    if($LASTEXITCODE -ne 0){throw 'Не удалось установить зависимости'}
}
& $pythonPath (Join-Path $kitRoot 'manager.py') $Action
exit $LASTEXITCODE
