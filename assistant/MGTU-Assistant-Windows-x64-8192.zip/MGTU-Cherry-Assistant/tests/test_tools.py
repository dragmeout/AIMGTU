import unittest,tempfile,zipfile,io,json,hashlib,sqlite3,os,sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from mgtu_mcp.documents import docx,parse_document,DocumentError
from mgtu_mcp.web import safe_target,WebError
from mgtu_mcp import knowledge as kb
from mgtu_mcp.__main__ import call_tool

def fixture():
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w') as z:
        z.writestr('word/document.xml','''<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:pPr><w:outlineLvl w:val="0"/></w:pPr><w:r><w:t>Условия практики</w:t></w:r></w:p><w:p><w:r><w:t>Практика длится 14 дней.</w:t></w:r></w:p><w:tbl><w:tr><w:tc><w:p><w:r><w:t>Группа</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Часы</w:t></w:r></w:p></w:tc></w:tr><w:tr><w:tc><w:p><w:r><w:t>Альфа</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>24</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:body></w:document>''')
    return b.getvalue()

class ToolsTest(unittest.TestCase):
    def test_docx_structure_and_table(self):
        meta,blocks=docx(fixture());self.assertEqual(blocks[0]['kind'],'heading');self.assertEqual(blocks[1]['section'],['Условия практики'])
        self.assertEqual(blocks[2]['table']['rows'][1]['cells'],['Альфа','24']);self.assertTrue(all(b['page'] is None for b in blocks));self.assertIn('Таблица 1',blocks[2]['locator'])
    def test_no_entities(self):
        from mgtu_mcp.documents import xml
        with self.assertRaises(DocumentError):xml(b'<!DOCTYPE foo [<!ENTITY x SYSTEM "file:///secret">]><foo>&x;</foo>')
    def test_ssrf(self):
        for url in ['http://127.0.0.1/','http://[::1]/','http://169.254.169.254/','http://localhost/','http://192.168.1.1/','file:///C:/secret','https://user:pass@magtu.ru/','http://magtu.ru:11439/']:
            with self.subTest(url=url),self.assertRaises((WebError,ValueError)):safe_target(url)
    def test_dns_rebinding_target_and_query(self):
        public=[(2,1,6,'',('8.8.8.8',443))]
        with patch('socket.getaddrinfo',return_value=public):
            target=safe_target('https://www.magtu.ru/file?q=a%26b')[4];self.assertEqual(target,'/file?q=a%26b')
        with patch('socket.getaddrinfo',return_value=public+[(2,1,6,'',('10.0.0.1',443))]),self.assertRaises(WebError):safe_target('https://www.magtu.ru/')
    def test_tool_validation_and_shell_absence(self):
        with self.assertRaises(ValueError):call_tool('shell',{'command':'whoami'})
        with self.assertRaises(ValueError):call_tool('read_document',{'name':'a','execute':True})
        with self.assertRaises(ValueError):call_tool('web_search',{'query':'test','limit':999})
    def test_project_isolation_and_sync(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);docs=root/'documents';docs.mkdir();p=docs/'данные.txt';p.write_text('Практика длится 14 дней.',encoding='utf-8')
            def fake_api(path,*a,**k):return {'models':[{'name':'qwen3-embedding:0.6b','digest':'test'}]}
            with patch.multiple(kb,PROJECT_ROOT=root,DOCUMENTS=docs,INDEX=root/'index.sqlite'),patch.object(kb,'embed',side_effect=lambda texts,query=False:[[1.,0.] for _ in texts]),patch.object(kb,'ollama',side_effect=fake_api):
                self.assertEqual(kb.synchronize()['updated'],1);self.assertEqual(kb.synchronize()['updated'],0)
                p.write_text('Теперь практика 21 день.',encoding='utf-8');self.assertEqual(kb.synchronize()['updated'],1)
                with kb.connect() as d:self.assertNotIn('14 дней',d.execute('select content from chunks').fetchone()[0])
                with self.assertRaises(DocumentError):kb.resolve_document('../secret.txt')
                p.unlink();self.assertEqual(kb.synchronize()['deleted'],1)
                with kb.connect() as d:self.assertEqual(d.execute('select count(*) from chunks').fetchone()[0],0)
    def test_attachment_handle_bridge(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);profile=root/'profile';(profile/'Data/Files').mkdir(parents=True);ident='test-file-uuid'
            with sqlite3.connect(profile/'Data/cherrystudio.sqlite') as d:d.execute('create table file_entry(id,name,ext,origin,deleted_at)');d.execute('insert into file_entry values(?,?,?,?,?)',(ident,'Таблица','docx','internal',None))
            d.close()
            (profile/'Data/Files'/f'{ident}.docx').write_bytes(fixture());handle='file_'+hashlib.sha256(ident.encode()).hexdigest()[:16]
            with patch.object(kb,'ROOT',root),patch.object(kb,'config',return_value={'cherry_profile':'profile'}):
                r=kb.attachment_candidates(handle);self.assertEqual(r[0]['name'],'Таблица.docx');self.assertEqual(kb.attachment_candidates('other-file'),[])
    def test_unsupported_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'test.exe';p.write_bytes(b'abc')
            with self.assertRaisesRegex(DocumentError,'Неподдерживаемый'):parse_document(p)
    def test_chat_bridge_aliases_and_attachment_scope(self):
        from mgtu_mcp.chat_bridge import prepare,restore
        wire='mcp__server__readDocument_abc'
        body={'model':'qwen3.5:9b','messages':[{'role':'user','content':'old Attached file "other.docx": text'},{'role':'user','content':'Attached file "current.docx": table'}],'tools':[{'type':'function','function':{'name':wire}},{'type':'function','function':{'name':'shell'}}]}
        result={'filename':'current.docx','blocks':[{'kind':'paragraph','locator':'Таблица 1, строка 2','text':'Альфа | 24'}],'truncated':False,'page_policy':'DOCX без страниц'}
        with patch.object(kb,'attachment_candidates',side_effect=lambda n:[{}] if n=='current.docx' else []),patch.object(kb,'read_document',return_value=result) as reader:
            b,aliases,added=prepare(body)
        self.assertEqual(added,['current.docx']);reader.assert_called_once_with('current.docx',max_chars=12000)
        self.assertEqual(b['tools'][0]['function']['name'],'read_document');self.assertEqual(len(b['tools']),1)
        self.assertIn('Таблица 1',b['messages'][-1]['content']);self.assertNotIn('untrusted_structured',b['messages'][0]['content'])
        self.assertEqual(restore({'message':{'tool_calls':[{'function':{'name':'read_document'}}]}},aliases)['message']['tool_calls'][0]['function']['name'],wire)
if __name__=='__main__':unittest.main()
