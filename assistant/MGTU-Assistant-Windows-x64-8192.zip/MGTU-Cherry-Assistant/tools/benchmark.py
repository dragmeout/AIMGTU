"""Real local inference and memory measurements; no invented results."""
from pathlib import Path
import sys,time,json,threading,psutil
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from mgtu_mcp.knowledge import ollama
def main():
    samples=[];running=True
    def sample():
        while running:
            total=0
            for p in psutil.process_iter(['name','memory_info','exe']):
                try:
                    if 'ollama' in (p.info['name'] or '').lower() or 'cherry studio' in (p.info['name'] or '').lower():total+=p.info['memory_info'].rss
                except psutil.Error:pass
            samples.append(total);time.sleep(.25)
    thread=threading.Thread(target=sample,daemon=True);thread.start();results=[]
    try:
        for context in ([int(n) for n in sys.argv[1:]] or [4096,8192,16384]):
            started=time.monotonic()
            r=ollama('/api/chat',{'model':'qwen3.5:9b','stream':False,'think':False,'messages':[{'role':'system','content':'Отвечай кратко по-русски. Если данных нет, скажи об этом.'},{'role':'user','content':'В таблице документа: проект Альфа — 24 часа, проект Бета — 36 часов. На сколько часов Бета больше Альфы? Ответь одним предложением и укажи источник «Проверочная таблица».'}],'options':{'num_ctx':context,'num_predict':120,'temperature':0},'keep_alive':'15m'},timeout=240)
            from mgtu_mcp.knowledge import embed
            embed(['Проверка совместной загрузки моделей поиска и ответов.'])
            ps=ollama('/api/ps')
            results.append({'context':context,'seconds':round(time.monotonic()-started,2),'answer':r['message']['content'],'thinking_returned':bool(r['message'].get('thinking')),'eval_count':r.get('eval_count'),'tokens_per_second':round(r.get('eval_count',0)/max(.001,r.get('eval_duration',1)/1e9),2),'models':ps['models'],'peak_combined_rss_gib':round(max(samples)/2**30,3)})
    finally:running=False;thread.join(timeout=2)
    (ROOT/'reports').mkdir(exist_ok=True)
    suffix='-'+'-'.join(sys.argv[1:]) if sys.argv[1:] else ''
    (ROOT/('reports/model-benchmark'+suffix+'.json')).write_text(json.dumps({'measured_at':time.strftime('%Y-%m-%d %H:%M:%S'),'hardware':'Windows 11, Ryzen 5 5600, 32 GiB RAM, RX 6700 XT 12 GiB','measurements':results,'note':'RSS — сумма рабочих наборов процессов, не приватная память; VRAM оценивается Ollama size_vram, не общий расход всей ОС.'},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(results,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
