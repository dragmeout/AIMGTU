"""Bounded real Qwen tool loop for reproducible evaluation, not another chat UI."""
import sys,json,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from mgtu_mcp.knowledge import ollama
from mgtu_mcp.__main__ import TOOLS,call_tool

def run(question,tools=True,prior=None):
    prompt=(ROOT/'config/system_prompt.ru.md').read_text(encoding='utf-8')
    messages=prior or [{'role':'system','content':prompt}];messages.append({'role':'user','content':question});trace=[];started=time.monotonic()
    for step in range(6):
        body={'model':'qwen3.5:9b','messages':messages,'stream':False,'think':False,'options':{'num_ctx':32768,'num_predict':1600,'temperature':0.2},'keep_alive':-1}
        if tools:body['tools']=[{'type':'function','function':{'name':t['name'],'description':t['description'],'parameters':t['inputSchema']}} for t in TOOLS]
        r=ollama('/api/chat',body,timeout=240);m=r['message'];messages.append(m);calls=m.get('tool_calls',[])
        trace.append({'message':m,'eval_count':r.get('eval_count'),'prompt_eval_count':r.get('prompt_eval_count')})
        if not calls:return {'question':question,'answer':m.get('content',''),'seconds':round(time.monotonic()-started,2),'trace':trace,'messages':messages}
        for call in calls:
            f=call['function']
            try:result=call_tool(f['name'],f['arguments'])
            except Exception as e:result={'error':str(e)}
            text=json.dumps(result,ensure_ascii=False);messages.append({'role':'tool','tool_name':f['name'],'content':text});trace.append({'tool':f['name'],'result':result})
    return {'question':question,'error':'Лимит 6 шагов','seconds':round(time.monotonic()-started,2),'trace':trace,'messages':messages}
if __name__=='__main__':
    question=' '.join(sys.argv[1:]) or 'Кто ректор МГТУ имени Носова? Проверь официальный сайт.'
    r=run(question);path=ROOT/'reports'/('evaluation-'+str(time.time_ns())+'.json');path.parent.mkdir(exist_ok=True);path.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'report':str(path),'answer':r.get('answer'),'error':r.get('error'),'seconds':r['seconds']},ensure_ascii=False),flush=True)
