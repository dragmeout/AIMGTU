"""Refresh downloaded sources from the shipped registry; retain a version history.

Archived logical exports are preserved, never silently replaced by an unrelated page.
Run with this kit's Python; does not depend on the previous laboratory workspace.
"""
from pathlib import Path
import argparse,csv,hashlib,json,sys,time
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from mgtu_mcp import knowledge as kb
from mgtu_mcp.web import fetch,official
from mgtu_mcp.documents import parse_document

def run(limit=None):
    registry=kb.PROJECT_ROOT/'sources.csv'
    with registry.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f);fields=list(reader.fieldnames);rows=list(reader)
    if 'checked_at' not in fields:fields.append('checked_at')
    report=[];changed=0
    for row in rows:
        if row['file'].endswith('.archive.json'):
            report.append({'file':row['file'],'status':'archived_export_preserved'});continue
        if limit is not None and sum(r['status']!='archived_export_preserved' for r in report)>=limit:break
        path=(kb.DOCUMENTS/row['file']).resolve()
        if kb.DOCUMENTS.resolve() not in path.parents:raise ValueError('Registry path escapes project')
        url=row.get('resolved_source') or row.get('source')
        try:
            if not official(url):raise ValueError('Registry update is limited to official MGTU sources')
            page=fetch(url,max_bytes=25*1024*1024,timeout=30)
            if not official(page['url']):raise ValueError('Redirect left the official MGTU domain')
            digest=hashlib.sha256(page['body']).hexdigest()
            row['checked_at']=page['fetched_at']
            if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest()==digest:
                report.append({'file':row['file'],'status':'unchanged'});continue
            temporary=path.with_name(path.stem+'.updating'+path.suffix);temporary.write_bytes(page['body'])
            try:parse_document(temporary)
            except Exception:
                temporary.unlink(missing_ok=True);raise
            if path.exists():
                history=kb.PROJECT_ROOT/'history'/time.strftime('%Y%m%d-%H%M%S')/row['file'];history.parent.mkdir(parents=True,exist_ok=True)
                import shutil
                shutil.copy2(path,history)
            temporary.replace(path);row.update(sha256=digest,retrieved_at=page['fetched_at'],resolved_source=page['url'])
            metadata=kb.PROJECT_ROOT/'sources'/(hashlib.sha256(row['file'].encode()).hexdigest()+'.json')
            value=json.loads(metadata.read_text(encoding='utf-8')) if metadata.exists() else {}
            value.update(source=page['url'],retrieved_at=page['fetched_at'],sha256=digest)
            metadata.parent.mkdir(parents=True,exist_ok=True);metadata.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
            changed+=1;report.append({'file':row['file'],'status':'updated'})
        except Exception as e:report.append({'file':row['file'],'status':'error_old_version_preserved','error':str(e)})
    temporary=registry.with_suffix('.csv.tmp')
    with temporary.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    temporary.replace(registry)
    result={'changed':changed,'items':report};out=ROOT/'reports';out.mkdir(exist_ok=True)
    (out/'source-update.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--limit',type=int);a=p.parse_args()
    print(json.dumps(run(a.limit),ensure_ascii=False,indent=2))
