"""Ollama-compatible adapter evaluation, including Cherry-style MCP wire aliases."""
from pathlib import Path
import json,sys,time,urllib.request
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from mgtu_mcp.__main__ import TOOLS,call_tool
from mgtu_mcp.chat_bridge import CAMEL
from mgtu_mcp.knowledge import config

def run(question,prior=None):
    names={snake:'mcp__server__'+camel+'_wiretest' for camel,snake in CAMEL.items()};reverse={v:k for k,v in names.items()}
    messages=prior or [{'role':'system','content':(ROOT/'config/system_prompt.ru.md').read_text(encoding='utf-8')}];messages.append({'role':'user','content':question});trace=[];start=time.monotonic()
    op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for _ in range(6):
        b={'model':config()['chat_model'],'messages':messages,'stream':False,'tools':[{'type':'function','function':{'name':names[t['name']],'description':t['description'],'parameters':t['inputSchema']}} for t in TOOLS]}
        req=urllib.request.Request('http://127.0.0.1:'+str(config().get('mcp_port',11440))+'/api/chat',data=json.dumps(b,ensure_ascii=False).encode(),headers={'Content-Type':'application/json'})
        with op.open(req,timeout=180) as response:r=json.load(response)
        m=r['message'];messages.append(m);trace.append(m)
        if not m.get('tool_calls'):return {'answer':m.get('content',''),'seconds':round(time.monotonic()-start,2),'trace':trace,'messages':messages}
        for c in m['tool_calls']:
            f=c['function'];tool=reverse[f['name']]
            try:result=call_tool(tool,f['arguments'])
            except Exception as e:result={'error':str(e)}
            trace.append({'tool':tool,'result':result});messages.append({'role':'tool','tool_name':f['name'],'content':json.dumps(result,ensure_ascii=False)})
    return {'error':'tool step limit','trace':trace,'seconds':round(time.monotonic()-start,2)}
if __name__=='__main__':
    q=' '.join(sys.argv[1:]) or 'По прикреплённому файлу: сколько дней длится практика, сколько часов у Альфы и номер таблицы/строки? Attached file "Проверка_таблицы.docx":\nУсловия практики\nПрактика длится 14 дней.\nГруппа\nЧасы\nАльфа\n24'
    result=run(q);p=ROOT/'reports'/('bridge-evaluation-'+str(time.time_ns())+'.json');p.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({'report':p.name,'answer':result.get('answer'),'seconds':result['seconds'],'error':result.get('error')},ensure_ascii=False),flush=True)
