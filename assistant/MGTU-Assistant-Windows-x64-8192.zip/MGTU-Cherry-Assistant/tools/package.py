"""Build allow-listed redistributable ZIP64 kits, excluding all user profiles/state."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,sqlite3,sys,time,zipfile
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parents[1]/'outputs/cherry-mgtu-v1';OUT.mkdir(parents=True,exist_ok=True)
PREFIX='MGTU-Cherry-Assistant'
DEV_ONLY={'seed_profile.py','prepare_local.py','corpus.py','enrich_corpus.py','replay_tools.py'}
PUBLIC_REPORTS={'model-benchmark.json','model-benchmark-32768.json','integration.json','shell-syntax.json','unicode-path.json','source-update.json','gui-check.json','gui-docx.png','gui-web.png','gui-kb.png','mcp-transport.json'}

def files():
    result=[]
    for p in ROOT.iterdir():
        if p.is_file() and (p.suffix in ['.cmd','.sh','.ps1'] or p.name in ['README.md','LICENSE','THIRD_PARTY.md','manager.py','requirements.txt'] or p.name.endswith('.lock.json')):result.append(p)
    for folder in ['config','docs','mgtu_mcp','tests','tools','licenses']:
        for p in (ROOT/folder).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name not in DEV_ONLY and p.name!='Cherry-Studio-source.tar.gz':result.append(p)
    for rel in ['documents','sources']:
        result.extend(p for p in (ROOT/'data/projects/mgtu'/rel).rglob('*') if p.is_file())
    for name in ['sources.csv','collection_issues.json']:
        p=ROOT/'data/projects/mgtu'/name
        if p.exists():result.append(p)
    for name in PUBLIC_REPORTS:
        p=ROOT/'reports'/name
        if p.exists():result.append(p)
    return sorted(set(result))

def safe_text(raw):
    text=raw.decode('utf-8-sig')
    # Reports are test artifacts, never include machine-specific filesystem paths.
    text=text.replace(str(ROOT).replace('\\','\\\\'),'<KIT>').replace(str(ROOT),'<KIT>').replace(ROOT.as_posix(),'<KIT>')
    return text.encode('utf-8')

def add(z,p,name):
    mode=zipfile.ZIP_STORED if p.suffix.lower() in ['.gguf','.gz','.pdf','.docx','.png','.jpg','.gif','.zip','.7z'] or 'blobs' in p.parts else zipfile.ZIP_DEFLATED
    if p.suffix=='.json' and 'reports' in p.parts:z.writestr(name,safe_text(p.read_bytes()),compress_type=mode)
    else:z.write(p,name,compress_type=mode)

def make(osname,arch,offline=False):
    flavor='Offline' if offline else 'Bootstrap';name=f'{PREFIX}-{osname}-{arch}-{flavor}.zip';target=OUT/name
    stage=ROOT/'.cache/packaging';stage.mkdir(parents=True,exist_ok=True)
    index=stage/'index.sqlite'
    with sqlite3.connect(ROOT/'data/projects/mgtu/index.sqlite') as src,sqlite3.connect(index) as dst:src.backup(dst)
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True) as z:
        for p in files():add(z,p,PREFIX+'/'+p.relative_to(ROOT).as_posix())
        add(z,index,PREFIX+'/data/projects/mgtu/index.sqlite')
        cfg={'ollama_url':'http://127.0.0.1:11439','mcp_port':11440,'chat_model':'qwen3.5:9b','embedding_model':'qwen3-embedding:0.6b','context':32768,'max_output_tokens':1600,'temperature':0.2,'chat_thinking':False,'offline':False,'cherry_profile':'runtime/cherry/data' if osname=='windows' else 'data/cherry-profile'}
        z.writestr(PREFIX+'/data/config.json',json.dumps(cfg,indent=2))
        z.writestr(PREFIX+'/bundle.json',json.dumps({'os':osname,'arch':arch,'type':flavor,'tested_os':'Windows x64 only','requires_first_cherry_import':True},indent=2))
        # Only supported imports with relative/address-only data; no local stdio absolute paths.
        for name in ['assistant.json','provider.json','provider-uri.txt','mcp-http.json','mcp-uri.txt']:add(z,ROOT/'imports'/name,PREFIX+'/imports/'+name)
        if offline:
            for folder in ['runtime/ollama','runtime/python','data/ollama/models']:
                for p in sorted((ROOT/folder).rglob('*')):
                    if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':add(z,p,PREFIX+'/'+p.relative_to(ROOT).as_posix())
            add(z,ROOT/'runtime/cherry/Cherry-Studio.exe',PREFIX+'/runtime/cherry/Cherry-Studio.exe')
            add(z,ROOT/'licenses/Cherry-Studio-source.tar.gz',PREFIX+'/licenses/Cherry-Studio-source.tar.gz')
    with target.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    item={'file':target.name,'bytes':target.stat().st_size,'sha256':digest,'offline':offline,'os':osname,'arch':arch}
    print(json.dumps(item),flush=True);return item

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--offline-only',action='store_true');parser.add_argument('--bootstrap-only',action='store_true');a=parser.parse_args();items=[]
    if not a.offline_only:
        for osname in ['windows','macos','linux']:
            for arch in ['x64','arm64']:items.append(make(osname,arch))
    if not a.bootstrap_only:items.append(make('windows','x64',True))
    old=OUT/'archives.json';previous=json.loads(old.read_text()) if old.exists() else []
    current={r['file']:r for r in previous};current.update({r['file']:r for r in items});items=sorted(current.values(),key=lambda r:r['file'])
    old.write_text(json.dumps(items,indent=2),encoding='utf-8');(OUT/'SHA256SUMS.txt').write_text(''.join(r['sha256']+'  '+r['file']+'\n' for r in items),encoding='ascii')
