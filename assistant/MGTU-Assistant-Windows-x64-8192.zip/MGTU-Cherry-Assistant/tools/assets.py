"""Read official release metadata and download checksum-pinned components."""
from pathlib import Path
import concurrent.futures,hashlib,html,json,re,sys,time,urllib.request

ROOT=Path(__file__).resolve().parents[1]
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def download(asset):
    target=ROOT/'.cache/downloads'/asset['name'];target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists() and (not asset.get('sha256') or digest(target)==asset['sha256']):return target
    part=target.with_name(target.name+'.part')
    for attempt in range(4):
        offset=part.stat().st_size if part.exists() else 0
        request=urllib.request.Request(asset['url'],headers={'User-Agent':'MGTU-Local-Assistant/1.0','Range':f'bytes={offset}-'} if offset else {'User-Agent':'MGTU-Local-Assistant/1.0'})
        try:
            with urllib.request.urlopen(request,timeout=60) as response:
                append=offset>0 and response.status==206
                with part.open('ab' if append else 'wb') as f:
                    while block:=response.read(1024*1024):f.write(block)
            actual=digest(part)
            if asset.get('sha256') and actual!=asset['sha256']:
                part.unlink(missing_ok=True)
                raise ValueError('Checksum mismatch: '+asset['name'])
            part.replace(target);print('Downloaded '+asset['name']+' '+str(target.stat().st_size),flush=True);return target
        except Exception as error:
            if isinstance(error,urllib.error.HTTPError) and error.code==416:part.unlink(missing_ok=True)
            if attempt==3:raise
            time.sleep(2)

def catalog():
    assets=[]
    for prefix in ['cherry','ollama']:
        text=(ROOT/'.cache/metadata'/f'{prefix}-assets.html').read_text(encoding='utf-8')
        for row in text.split('<li '):
            link=re.search(r'href="(/[^\"]+/releases/download/[^\"]+)"',row)
            check=re.search(r'value="sha256:([a-f0-9]{64})"',row)
            if link:
                url='https://github.com'+html.unescape(link[1]);assets.append({'name':url.rsplit('/',1)[1],'url':url,'sha256':check[1] if check else ''})
    hashes={line.split()[-1].removeprefix('./'):line.split()[0] for line in (ROOT/'.cache/metadata/ollama-sha256sum.txt').read_text().splitlines() if line.strip()}
    for a in assets:
        if a['name'] in hashes:a['sha256']=hashes[a['name']]
    lock={'cherry_version':'2.1.10','cherry_commit':'c60cd41a66d50920d75950fe3ed614c23bdeacca','ollama_version':'0.40.15','assets':assets}
    (ROOT/'assets.lock.json').write_text(json.dumps(lock,ensure_ascii=False,indent=2),encoding='utf-8')
    return lock

if __name__=='__main__':
    lock=catalog()
    selected=[a for a in lock['assets'] if a['name'] in sys.argv[1:]]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for p in pool.map(download,selected):print(p,flush=True)
